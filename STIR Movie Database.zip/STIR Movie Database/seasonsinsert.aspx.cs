﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class seasonsinsert : System.Web.UI.Page
    {
        SqlConnection con;

        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand q2 = new SqlCommand("Select MAX(sid) from seasonss", con);
            SqlDataReader r1 = q2.ExecuteReader();
            r1.Read();
            int newid = int.Parse(r1.GetValue(0).ToString());
            newid = ++newid;
            r1.Close();


            SqlCommand q1 = new SqlCommand($"Insert into seasonss values({newid},'" + TextBox1.Text + "','" + int.Parse(TextBox2.Text) + "','" + int.Parse(TextBox13.Text) + "','" + (TextBox13.Text) + "','" + float.Parse(TextBox4.Text) + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + int.Parse(TextBox7.Text) + "','" + TextBox8.Text + "','" + TextBox9.Text + "')", con);
            q1.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);
            
        }
    }
}