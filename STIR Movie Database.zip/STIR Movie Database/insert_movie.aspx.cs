﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class insert_movie : System.Web.UI.Page
    {
        //        SqlConnection con;
        //        protected void move1(object sender, EventArgs e)
        //        {
        //            SqlCommand q2 = new SqlCommand("Select MAX(Mid) from movies", con);
        //            SqlDataReader r1 = q2.ExecuteReader();
        //            r1.Read();
        //            int newid = int.Parse(r1.GetValue(0).ToString());
        //            newid = ++newid;
        //            SqlCommand q1 = new SqlCommand($"Insert into movies values({newid},'" + TextBox1.Text + "','" + int.Parse(TextBox2.Text) + "','" + TextBox3.Text + "','" + float.Parse(TextBox4.Text) + "','" + TextBox5.Text + "','" + TextBox6.Text + "','','" + int.Parse(TextBox7.Text) + "','" + TextBox8.Text + "','" + TextBox9.Text + "')", con);
        //            q1.ExecuteNonQuery();
        //            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);
        //            if (TextBox10.Text != "")
        //            {
        //                SqlCommand q3 = new SqlCommand($"Insert into Mgenres values('" + newid + "','" + TextBox10.Text + "',1)", con);
        //                q3.ExecuteNonQuery();
        //            }
        //            if (TextBox11.Text != "")
        //            {
        //                SqlCommand q3 = new SqlCommand($"Insert into Mgenres values('" + newid + "','" + TextBox11.Text + "',2)", con);
        //                q3.ExecuteNonQuery();
        //            }
        //            if (TextBox12.Text != "")
        //            {
        //                SqlCommand q3 = new SqlCommand($"Insert into Mgenres values('" + newid + "','" + TextBox12.Text + "',3)", con);
        //                q3.ExecuteNonQuery();
        //            }
        //            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);

        //        }
        //        protected void Page_Load(object sender, EventArgs e)
        //        {
        //            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
        //            con.Open();
        //            // move1(sender, e);
        //        }
           }
    }