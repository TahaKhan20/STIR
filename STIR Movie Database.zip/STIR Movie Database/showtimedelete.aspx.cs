﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class showtimedelete : System.Web.UI.Page
    {
        SqlConnection con;
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand q1 = new SqlCommand("DELETE showtimes FROM showtimes INNER JOIN movies ON showtimes.mid = movies.mid WHERE cinema = @cinema AND dates = @date AND city = @city AND timing = @time AND mid = @mid", con);
            q1.Parameters.AddWithValue("@cinema", TextBox1.Text);
            q1.Parameters.AddWithValue("@date", TextBox2.Text);
            q1.Parameters.AddWithValue("@city", TextBox4.Text);
            q1.Parameters.AddWithValue("@time", TextBox3.Text);
            SqlCommand a2 = new SqlCommand("select mid from movies where Mname=@mname", con);
            a2.Parameters.AddWithValue("@mname", TextBox5.Text);
            SqlDataReader p2 = a2.ExecuteReader();
            int amid = 0;
            if (p2.Read())
            {
                string id2 = p2.GetValue(0).ToString();
                amid = int.Parse(id2);
            }
            q1.Parameters.AddWithValue("@mid", amid);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Deleted')", true);
        }
    }
}