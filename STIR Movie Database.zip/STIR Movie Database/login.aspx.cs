﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class login : System.Web.UI.Page
    {
        SqlConnection con;
        protected void check(object sender, EventArgs e)
        {
            string uemail = First.Text;
            string upassword = Second.Text;
            SqlCommand q2 = new SqlCommand($"Select * from userr where uemail='{uemail}' AND upassword='{upassword}'", con);
            SqlDataReader r2 = q2.ExecuteReader();
            r2.Read();
            SqlCommand q1 = new SqlCommand($"Select Count(*) from userr where uemail='{uemail}' AND upassword='{upassword}'", con);
            SqlDataReader r1 = q1.ExecuteReader();
            r1.Read();
            if (int.Parse(r1.GetValue(0).ToString()) > 0)
            {
                Application["id"] = int.Parse(r2.GetValue(0).ToString());
                Response.Redirect("https://localhost:44312/WebForm6.aspx");
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Wrong Email or password')", true);
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
        }
    }
}