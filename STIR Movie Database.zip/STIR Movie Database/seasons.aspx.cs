﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class seasons : System.Web.UI.Page
    {
        SqlConnection con;
        int id;
        int i = 0;
        int epcount;
        int sid;
        protected void Querybut(object sender, EventArgs e)
        {
            sid = int.Parse(ddlMenu.SelectedValue);
            move(sender, e);
        }

        protected void func1(object sender, EventArgs e)
        {

            i++;
            move(sender, e);

        }
        protected void move(object sender, EventArgs e)
        {

            SqlCommand q1 = new SqlCommand($"Select * from sepno join episodes on sepno.sid= episodes.sid where sepno.seasonno={sid} AND sepno.sid={id} AND episodes.seasonno={sid}", con);
            SqlDataReader sr = q1.ExecuteReader();
            SqlCommand q2 = new SqlCommand($"Select Count(*) from sepno join episodes on sepno.sid= episodes.sid where sepno.seasonno={sid} AND sepno.sid={id} AND episodes.seasonno= {sid}", con);
            SqlDataReader sr1 = q2.ExecuteReader();
            sr1.Read();
            epcount = int.Parse(sr1.GetValue(0).ToString());
            epcou.Text = sr1.GetValue(0).ToString();
            int a = 0;
            while (a < i && a < epcount)
            {
                a++;
                sr.Read();

            }

            if (a < epcount)
            {
                sr.Read();
                epname.Text = sr.GetValue(6).ToString();
                epdesc.Text = sr.GetValue(9).ToString();
                epimg.ImageUrl = sr.GetValue(7).ToString();
                eprating.Text = sr.GetValue(8).ToString();
                int val = i + 1;
                i4.Text = $"EPISODE : {val}";
                //   epinfo.Text = $"<a id = \"i4\" style = \"position:absolute;margin-top:640px; margin-left:420px;color:whitesmoke\" > EPISODE : {val}</ a>";

            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            // string parameterValue = Request.QueryString["i"];
            id = int.Parse(Request.QueryString["i"]);
            
            string nam;
            string ratin;
            string poste;
            string traile;
            string date;
            sid = int.Parse(ddlMenu.SelectedValue);
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
            SqlCommand s1 = new SqlCommand($"Select * from seasons where Sid={id}", con);
            SqlDataReader r1 = s1.ExecuteReader();
            r1.Read();
            date1.Text = r1.GetValue(2).ToString();
            name.Text = r1.GetValue(1).ToString();
            rating.Text = r1.GetValue(4).ToString();
            poster.ImageUrl = r1.GetValue(6).ToString();
            nextep.Text = "Next Episode";
            string src = r1.GetValue(5).ToString();
            trailer.Text = $"<iframe style=\"margin-left:20px  ;position:absolute;margin-top:30px; \" width=\"700\" height=\"419\" src=\"{src}\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>";
            int val = 1;
            //  epinfo.Text = $"<a id = \"i4\" style = \"position:absolute;margin-top:640px; margin-left:420px;color:whitesmoke\" > EPISODE : {val}</a>";



            SqlCommand genc = new SqlCommand($"Select COUNT(*) from sgenres where sid={id}", con);
            SqlDataReader r3 = genc.ExecuteReader();
            r3.Read();
            int genrecount = (int.Parse(r3.GetValue(0).ToString()));
            int x = 0;
            SqlCommand gen = new SqlCommand($"Select * from sgenres where sid={id}", con);
            SqlDataReader r4 = gen.ExecuteReader();
            if (x < genrecount)
            {
                r4.Read();
                string gen1 = r4.GetValue(1).ToString();
                Button1.Text = gen1;
                Button1.Style["Display"] = "inline-block";
            }
            else
            {


            }
            x++;
            if (x < genrecount)
            {
                r4.Read();
                string gen1 = r4.GetValue(1).ToString();
                Button2.Text = gen1;
                Button2.Style["Display"] = "inline-block";
            }
            else
            {
                Button2.Visible = false;

            }
            x++;
            if (x < genrecount)
            {
                r4.Read();
                string gen1 = r4.GetValue(1).ToString();
                Button3.Text = gen1;
            }
            else
            {
                Button3.Visible = false;
                // genre3.Text = "lol";
                //  genre3.Visible = false;
            }
            move(sender, e);
        }
    }
}