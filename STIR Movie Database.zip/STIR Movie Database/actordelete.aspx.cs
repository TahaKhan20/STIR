﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class actordelete : System.Web.UI.Page
    {

        SqlConnection con;
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand q1 = new SqlCommand("DELETE FROM aextra WHERE aid IN (SELECT aid FROM actor WHERE aname = @aname) AND date1 = @date1", con);
            q1.Parameters.AddWithValue("@aname", TextBox1.Text);
            q1.Parameters.AddWithValue("@date1", TextBox2.Text);
            q1.ExecuteNonQuery();

            // Then, delete records from the 'directorssss' table
            SqlCommand q2 = new SqlCommand("DELETE FROM actor WHERE aname = @aname", con);
            q2.Parameters.AddWithValue("@aname", TextBox1.Text);
            q2.ExecuteNonQuery();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Deleted')", true);
        }
    }
}