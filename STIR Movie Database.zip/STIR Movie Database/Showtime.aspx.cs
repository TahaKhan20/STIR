﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class Showtime : System.Web.UI.Page
    {
        public static int count;
        public static int j = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
                        
            string s1 = city.SelectedValue;
            string d1 = Date.SelectedValue;
            string c1 = cinema.SelectedValue;
            string m1 = movie.SelectedValue;

            if (s1 == "Select" && d1=="Select" && m1=="Select" && c1=="Select")
            {
                SqlCommand all = new SqlCommand("select * from showtimes join movies on movies.MID=showtimes.MID", con);
                SqlDataReader r = all.ExecuteReader();

                SqlCommand com = new SqlCommand("select count(*) from showtimes join movies on movies.MID=showtimes.MID", con);

                SqlDataReader c = com.ExecuteReader();
                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            else if (s1 != "Select" && d1 != "Select" && m1 == "Select" && c1 == "Select")
            {

                SqlCommand movie = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}' and city=@city", con);
                movie.Parameters.AddWithValue("@city", s1);
                movie.Parameters.AddWithValue("@dates", d1);
                SqlDataReader r = movie.ExecuteReader();
                
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}' and city=@city", con);
                com.Parameters.AddWithValue("@city", s1);
                com.Parameters.AddWithValue("@dates", d1);
                SqlDataReader c = com.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            else if(s1!="Select" && d1 == "Select" && m1 == "Select" && c1 == "Select")
            {
                
                SqlCommand movie = new SqlCommand("select * from showtimes join movies on movies.MID=showtimes.MID where city=@city", con);
                movie.Parameters.AddWithValue("@city", s1);

                SqlDataReader r = movie.ExecuteReader();
                SqlCommand com = new SqlCommand("select count(*) from showtimes join movies on movies.MID=showtimes.MID where city=@city", con);
                com.Parameters.AddWithValue("@city", s1);
                SqlDataReader c = com.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            else if (d1 != "Select" && s1 == "Select" && m1 == "Select" && c1 == "Select")
            {
                SqlCommand movie = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}' ", con);
                SqlDataReader r = movie.ExecuteReader();
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}'", con);
                SqlDataReader c = com.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            else if (s1 == "Select" && d1 == "Select" && m1 == "Select" && c1 != "Select")
            {
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}'", con);

                SqlDataReader c = com.ExecuteReader();
                SqlCommand movie = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}'", con);
                SqlDataReader r = movie.ExecuteReader();
                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            else if (s1 == "Select" && d1 != "Select" && m1 == "Select" && c1 != "Select")
            {
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}' and cinema='{c1}'", con);
                SqlDataReader c = com.ExecuteReader();
                SqlCommand movies = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}' and cinema='{c1}'", con);
                SqlDataReader r = movies.ExecuteReader();
                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(4).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visible";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }


            }
            else if (s1 != "Select" && d1 == "Select" && m1 == "Select" && c1 != "Select")
            {
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where city='{s1}' and cinema='{c1}'", con);
                SqlDataReader c = com.ExecuteReader();
                SqlCommand movies = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where city='{s1}' and cinema='{c1}'", con);
                SqlDataReader r = movies.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visible";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }
            }
            else if (s1 != "Select" && d1 != "Select" && m1 == "Select" && c1 != "Select")
            {
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}' and cinema='{c1}' and city='{s1}'", con);
                SqlDataReader c = com.ExecuteReader();
                SqlCommand movies = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}' and cinema='{c1}' and city='{s1}'", con);
                SqlDataReader r = movies.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visible";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }


            }
            else if (s1 == "Select" && d1 == "Select" && m1 != "Select" && c1 == "Select")
            {
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where Mname='{m1}'", con);
                SqlDataReader c = com.ExecuteReader();
                SqlCommand movies = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where Mname='{m1}'", con);
                SqlDataReader r = movies.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            else if (s1 == "Select" && d1 != "Select" && m1 != "Select" && c1 == "Select")
            {

                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where Mname='{m1}' and dates='{d1}'", con);
                SqlDataReader c = com.ExecuteReader();
                SqlCommand movies = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where Mname='{m1}' and dates='{d1}'", con);
                SqlDataReader r = movies.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            else if (s1 != "Select" && d1 == "Select" && m1 != "Select" && c1 == "Select")
            {

                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where Mname='{m1}' and city='{s1}'", con);
                SqlDataReader c = com.ExecuteReader();
                SqlCommand movies = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where Mname='{m1}' and city='{s1}'", con);
                SqlDataReader r = movies.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            else if (d1 != "Select" && s1 != "Select" && m1 != "Select" && c1 == "Select")
            {
                SqlCommand movie = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}' and Mname='{m1}' and city='{s1}' ", con);
                SqlDataReader r = movie.ExecuteReader();
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where dates='{d1}' and Mname='{m1}' and city='{s1}'", con);
                SqlDataReader c = com.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            
            else if (s1 == "Select" && d1 == "Select" && m1 != "Select" && c1 != "Select")
            {
                SqlCommand movie = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}' and Mname='{m1}'", con);
                SqlDataReader r = movie.ExecuteReader();
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}' and Mname='{m1}'", con);
                SqlDataReader c = com.ExecuteReader();
                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }

            }
            else if (s1 == "Select" && d1 != "Select" && m1 != "Select" && c1 != "Select")
            {
                SqlCommand movie = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}' and Mname='{m1}' and dates='{d1}'", con);
                SqlDataReader r = movie.ExecuteReader();
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}' and Mname='{m1}' and dates='{d1}'", con);
                SqlDataReader c = com.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visible";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }


            }
            else if (s1 != "Select" && d1 == "Select" && m1 != "Select" && c1 != "Select")
            {
                SqlCommand movie = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}' and Mname='{m1}' and city='{s1}'", con);
                SqlDataReader r = movie.ExecuteReader();
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}' and Mname='{m1}' and city='{s1}'", con);
                SqlDataReader c = com.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visible";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }
            }
            else if (s1 != "Select" && d1 != "Select" && m1 != "Select" && c1 != "Select")
            {
                SqlCommand movie = new SqlCommand($"select * from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}' and Mname='{m1}' and dates='{d1}' and city='{s1}'", con);
                SqlDataReader r = movie.ExecuteReader();
                SqlCommand com = new SqlCommand($"select count(*) from showtimes join movies on movies.MID=showtimes.MID where cinema='{c1}' and Mname='{m1}' and dates='{d1}' and city='{s1}'", con);
                SqlDataReader c = com.ExecuteReader();

                c.Read();
                string co = c.GetValue(0).ToString();
                count = int.Parse(co);
                if (count % 3 != 0)
                {
                    count = (3 - count % 3) + count;
                }
                int x = 0;
                while (x < j)
                {
                    r.Read();
                    x++;
                }
                if (x < count)
                {
                    noresult.Style["visibility"] = "hidden";
                    if (r.Read())
                    {
                        cinema0.Text = r.GetValue(0).ToString();
                        city0.Text = r.GetValue(1).ToString();
                        time0.Text = r.GetValue(2).ToString();
                        date0.Text = r.GetValue(3).ToString();
                        movie0.Text = r.GetValue(6).ToString();
                        cinema0.Visible = true;
                        city0.Visible = true;
                        time0.Visible = true;
                        date0.Visible = true;
                        movie0.Visible = true;
                        box1.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema0.Visible = false;
                        city0.Visible = false;
                        time0.Visible = false;
                        date0.Visible = false;
                        movie0.Visible = false;
                        box1.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema1.Text = r.GetValue(0).ToString();
                        city1.Text = r.GetValue(1).ToString();
                        time1.Text = r.GetValue(2).ToString();
                        date1.Text = r.GetValue(3).ToString();
                        movie1.Text = r.GetValue(6).ToString();
                        cinema1.Visible = true;
                        city1.Visible = true;
                        time1.Visible = true;
                        date1.Visible = true;
                        movie1.Visible = true;
                        box2.Style["visibility"] = "visibility";
                    }
                    else
                    {
                        cinema1.Visible = false;
                        city1.Visible = false;
                        time1.Visible = false;
                        date1.Visible = false;
                        movie1.Visible = false;
                        box2.Style["visibility"] = "hidden";
                    }
                    if (r.Read())
                    {
                        cinema2.Text = r.GetValue(0).ToString();
                        city2.Text = r.GetValue(1).ToString();
                        time2.Text = r.GetValue(2).ToString();
                        date2.Text = r.GetValue(3).ToString();
                        movie2.Text = r.GetValue(6).ToString();
                        cinema2.Visible = true;
                        city2.Visible = true;
                        time2.Visible = true;
                        date2.Visible = true;
                        movie2.Visible = true;
                        box3.Style["visibility"] = "visible";
                    }
                    else
                    {
                        cinema2.Visible = false;
                        city2.Visible = false;
                        time2.Visible = false;
                        date2.Visible = false;
                        movie2.Visible = false;
                        box3.Style["visibility"] = "hidden";
                    }
                }
                else
                {
                    noresult.Style["visibility"] = "visible";
                    over1.Style["visibility"] = "hidden";
                    box1.Style["visibility"] = "hidden";
                    box2.Style["visibility"] = "hidden";
                    box3.Style["visibility"] = "hidden";
                    Button1.Style["visibility"] = "hidden";
                    Button2.Style["visibility"] = "hidden";
                }


            }

        }
        protected void Search1(object sender, EventArgs e)
        {
            over1.Style["visibility"] = "visible";

        }
        protected void NextDir(object sender, EventArgs e)
        {
            j = j + 3;
            
            if (j >= count)
            {
                j = 0;
            }
            Page_Load(sender, e);
        }
        protected void PrevDir(object sender, EventArgs e)
        {
            j = j - 3;

            if (j < 0)
            {
                j = count-3;
                if (count % 3 != 0)
                {
                    j = j + count % 3;
                }
            }
            
            Page_Load(sender, e);
        }
    }
}