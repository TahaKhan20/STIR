﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class watchlist : System.Web.UI.Page
    {
        string val = "";
        string query = "Mrating desc";
        SqlConnection con;
        int count = 0;
        int flag = 0;
        int i = 0;
        int watchid1;
        int watchid2;
        int watchid3;
        int watchid4;
        int watchid5;
        protected void move1(object sender, EventArgs e)
        {
            if ((int)Application["id"] != 0)
            {
                SqlCommand se = new SqlCommand($"Insert into watchlist values({watchid1},'','{(int)Application["id"]}')", con);
                se.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Added')", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('User SignIn Required')", true);

            }
        }
        protected void move2(object sender, EventArgs e)
        {
            if ((int)Application["id"] != 0)
            {
                SqlCommand se = new SqlCommand($"Insert into watchlist values({watchid2},'','{(int)Application["id"]}')", con);
                se.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Added')", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('User SignIn Required')", true);

            }
        }
        protected void move3(object sender, EventArgs e)
        {
            if ((int)Application["id"] != 0)
            {
                SqlCommand se = new SqlCommand($"Insert into watchlist values({watchid3},'','{(int)Application["id"]}')", con);
                se.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Added')", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('User SignIn Required')", true);

            }
        }
        protected void move4(object sender, EventArgs e)
        {
            if ((int)Application["id"] != 0)
            {
                SqlCommand se = new SqlCommand($"Insert into watchlist values({watchid4},'','{(int)Application["id"]}')", con);
                se.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Added')", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('User SignIn Required')", true);

            }
        }
        protected void move5(object sender, EventArgs e)
        {
            if ((int)Application["id"] != 0)
            {
                SqlCommand se = new SqlCommand($"Insert into watchlist values({watchid5},'','{(int)Application["id"]}')", con);
                se.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Added')", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('User SignIn Required')", true);

            }
        }
        protected void ButtonNext(object sender, EventArgs e)
        {

            i += 5;
            move(sender, e);
        }
        protected void Querybut(object sender, EventArgs e)
        {
            val = TextBox1.Text;
            flag = 1;
            move(sender, e);
        }
        protected void ButtonPrev(object sender, EventArgs e)
        {
            if (i > 0)
            {


                i -= 5;
                move(sender, e);
            }
        }
        protected void Buttonselect(object sender, EventArgs e)
        {

            i = 0;
            move(sender, e);
        }

        protected void move(object sender, EventArgs e)
        {
            int uid = (int)Application["id"];
            query = ddlMenu.SelectedValue;
            int x = 0;
            SqlCommand coun;

            if (flag == 0)
            {
                coun = new SqlCommand($"Select * from movies  join watchlist on movies.Mid = watchlist.Mid where uid ={ uid } order by { query}", con);
                SqlCommand coun1 = new SqlCommand($"Select Count(*) from movies join watchlist on movies.Mid=watchlist.Mid where uid={uid}", con);
                SqlDataReader r4 = coun1.ExecuteReader();
                r4.Read();
                count = int.Parse(r4.GetValue(0).ToString());
            }
            else
            {
                coun = new SqlCommand($"Select * from movies join watchlist on movies.Mid= watchlist.Mid where uid={uid} AND  Mname like '%{val}%' ", con);
                SqlCommand coun1 = new SqlCommand($"Select Count(*) from movies join watchlist on movies.Mid= watchlist.Mid where uid={uid} AND  Mname like '%{val}%'", con);
                SqlDataReader r4 = coun1.ExecuteReader();
                r4.Read();
                count = int.Parse(r4.GetValue(0).ToString());
            }
            flag = 0;
            SqlDataReader r1 = coun.ExecuteReader();

            while (x < i && x < count)
            {
                r1.Read();
                x++;
            }
            if (x < count)
            {
                r1.Read();
                string ids = r1.GetValue(0).ToString();
                int id = int.Parse(ids);
                watchid1 = id;
                img.ImageUrl = r1.GetValue(6).ToString();
                name.Text = $"<a style=\"color: white;\" href=\"https://localhost:44312/WebForm2.aspx?i={id}\">{r1.GetValue(1).ToString()} ({r1.GetValue(2).ToString()})</a>";
                rate.Style["display"] = "inline-block";
                name.Style["display"] = "inline-block";
                name.Style["width"] = "300px";
                name.Style["font-size"] = "17px";
                name.Style["padding-top"] = "30px";
                rate.Style["padding-top"] = "30px";
                watch.Style["padding-top"] = "25px";
                watch.Style["color"] = "white";
                rate.Style["font-size"] = "17px";
                rate.Style["color"] = "white";
                img.Style["display"] = "inline-block";
                img.Style["color"] = "white";

                rate.Text = r1.GetValue(4).ToString();
                name.Style["visibility"] = "visible";
                rate.Style["visibility"] = "visible";
                img.Style["visibility"] = "visible";
                watch.Style["visibility"] = "visible";
            }
            else
            {
                Image1.Style["visibility"] = "hidden";
                name.Style["visibility"] = "hidden";
                rate.Style["visibility"] = "hidden";
                img.Style["visibility"] = "hidden";
                watch.Style["visibility"] = "hidden";

            }
            x++;

            if (x < count)
            {
                r1.Read();
                string ids = r1.GetValue(0).ToString();
                int id = int.Parse(ids);
                img1.ImageUrl = r1.GetValue(6).ToString();
                watchid2 = id;
                name1.Text = $"<a style=\"color:white\" href=\"https://localhost:44312/WebForm2.aspx?i={id}\">{r1.GetValue(1).ToString()} ({r1.GetValue(2).ToString()})</a>";
                rate1.Style["display"] = "inline-block";
                name1.Style["display"] = "inline-block";
                name1.Style["width"] = "300px";
                name1.Style["font-size"] = "17px";
                name1.Style["padding-top"] = "30px";
                rate1.Style["padding-top"] = "30px";
                watch1.Style["padding-top"] = "25px";
                rate1.Style["font-size"] = "17px";
                rate1.Style["color"] = "white";
                img1.Style["display"] = "inline-block";
                rate1.Text = r1.GetValue(4).ToString();
                name1.Style["visibility"] = "visible";
                rate1.Style["visibility"] = "visible";
                img1.Style["visibility"] = "visible";
                watch1.Style["visibility"] = "visible";
            }
            else
            {
                Image2.Style["visibility"] = "hidden";
                name1.Style["visibility"] = "hidden";
                rate1.Style["visibility"] = "hidden";
                img1.Style["visibility"] = "hidden";
                watch1.Style["visibility"] = "hidden";

            }
            x++;
            if (x < count)
            {
                r1.Read();

                string ids = r1.GetValue(0).ToString();
                int id = int.Parse(ids);
                watchid3 = id;
                img2.ImageUrl = r1.GetValue(6).ToString();
                name2.Text = $"<a style=\"color:white\" href=\"https://localhost:44312/WebForm2.aspx?i={id}\">{r1.GetValue(1).ToString()} ({r1.GetValue(2).ToString()})</a>";
                rate2.Style["display"] = "inline-block";
                name2.Style["display"] = "inline-block";
                name2.Style["width"] = "300px";
                name2.Style["font-size"] = "17px";
                name2.Style["padding-top"] = "30px";
                rate2.Style["padding-top"] = "30px";
                rate2.Style["color"] = "white";
                watch2.Style["padding-top"] = "25px";
                rate2.Style["font-size"] = "17px";
                img2.Style["display"] = "inline-block";
                rate2.Text = r1.GetValue(4).ToString();
                name2.Style["visibility"] = "visible";
                rate2.Style["visibility"] = "visible";
                img2.Style["visibility"] = "visible";
                watch2.Style["visibility"] = "visible";
            }
            else
            {
                Image3.Style["visibility"] = "hidden";
                name2.Style["visibility"] = "hidden";
                rate2.Style["visibility"] = "hidden";
                img2.Style["visibility"] = "hidden";
                watch2.Style["visibility"] = "hidden";

            }
            x++;
            if (x < count)
            {
                r1.Read();
                string ids = r1.GetValue(0).ToString();
                int id = int.Parse(ids);
                watchid4 = id;
                img3.ImageUrl = r1.GetValue(6).ToString();
                name3.Text = $"<a style=\"color:white\" href=\"https://localhost:44312/WebForm2.aspx?i={id}\">{r1.GetValue(1).ToString()} ({r1.GetValue(2).ToString()})</a>";
                rate3.Style["display"] = "inline-block";
                name3.Style["display"] = "inline-block";
                name3.Style["width"] = "300px";
                name3.Style["font-size"] = "17px";
                name3.Style["padding-top"] = "30px";
                rate3.Style["padding-top"] = "30px";
                rate3.Style["color"] = "white";
                watch3.Style["padding-top"] = "25px";
                rate3.Style["font-size"] = "17px";
                img3.Style["display"] = "inline-block";
                rate3.Text = r1.GetValue(4).ToString();
                name3.Style["visibility"] = "visible";
                rate3.Style["visibility"] = "visible";
                img3.Style["visibility"] = "visible";
                watch3.Style["visibility"] = "visible";
            }
            else
            {
                Image4.Style["visibility"] = "hidden";
                name3.Style["visibility"] = "hidden";
                rate3.Style["visibility"] = "hidden";
                img3.Style["visibility"] = "hidden";
                watch3.Style["visibility"] = "hidden";

            }
            x++;
            if (x < count)
            {
                r1.Read();
                string ids = r1.GetValue(0).ToString();
                int id = int.Parse(ids);
                watchid5 = id;
                img4.ImageUrl = r1.GetValue(6).ToString();
                name4.Text = $"<a style=\"color:white\" href=\"https://localhost:44312/WebForm2.aspx?i={id}\">{r1.GetValue(1).ToString()} ({r1.GetValue(2).ToString()})</a>";
                rate4.Style["display"] = "inline-block";
                name4.Style["display"] = "inline-block";
                name4.Style["width"] = "300px";
                name4.Style["font-size"] = "17px";
                name4.Style["padding-top"] = "30px";
                rate4.Style["padding-top"] = "30px";
                watch4.Style["margin-top"] = "25px";
                rate4.Style["color"] = "white";
                img4.Style["padding-bottom"] = "20px";
                rate4.Style["font-size"] = "17px";
                img4.Style["display"] = "inline-block";
                rate4.Text = r1.GetValue(4).ToString();
                name4.Style["visibility"] = "visible";
                rate4.Style["visibility"] = "visible";
                img4.Style["visibility"] = "visible";
                watch4.Style["visibility"] = "visible";
            }
            else
            {
                Image5.Style["visibility"] = "hidden";
                name4.Style["visibility"] = "hidden";
                rate4.Style["visibility"] = "hidden";
                img4.Style["visibility"] = "hidden";
                watch4.Style["visibility"] = "hidden";

            }
            x++;


        }
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label1.Text = Application["id"].ToString();
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
            SqlCommand coun = new SqlCommand($"Select COUNT(*) from movies ", con);
            SqlDataReader r1 = coun.ExecuteReader();
            r1.Read();
            string ids = r1.GetValue(0).ToString();
            count = int.Parse(ids);
            head1.Style["margin-left"] = "100px";
            head2.Style["margin-left"] = "600px";
            head1.Style["font-size"] = "20px";
            head2.Style["position"] = "absolute";
            head2.Style["font-size"] = "20px";
            head1.Style["position"] = "absolute";
            TextBox1.Style["position"] = "absolute";
            TextBox1.Style["margin-left"] = "100px";
            TextBox1.Style["margin-top"] = "30px";


            head3.Style["margin-left"] = "700px";
            head3.Style["font-size"] = "20px";
            head3.Style["position"] = "absolute";


            img.Style["margin-left"] = "100px";
            img.Style["position"] = "absolute";
            name.Style["margin-left"] = "180px";
            name.Style["position"] = "absolute";
            rate.Style["margin-left"] = "610px";
            rate.Style["position"] = "absolute";
            watch.Style["margin-left"] = "710px";
            watch.Style["position"] = "absolute";

            img1.Style["margin-left"] = "100px";
            img1.Style["position"] = "absolute";
            name1.Style["margin-left"] = "180px";
            name1.Style["position"] = "absolute";
            rate1.Style["margin-left"] = "610px";
            rate1.Style["position"] = "absolute";
            watch1.Style["margin-left"] = "710px";
            watch1.Style["position"] = "absolute";

            img2.Style["margin-left"] = "100px";
            img2.Style["position"] = "absolute";
            name2.Style["margin-left"] = "180px";
            name2.Style["position"] = "absolute";
            rate2.Style["margin-left"] = "610px";
            rate2.Style["position"] = "absolute";
            watch2.Style["margin-left"] = "710px";
            watch2.Style["position"] = "absolute";

            img3.Style["margin-left"] = "100px";
            img3.Style["position"] = "absolute";
            name3.Style["margin-left"] = "180px";
            name3.Style["position"] = "absolute";
            rate3.Style["margin-left"] = "610px";
            rate3.Style["position"] = "absolute";
            watch3.Style["margin-left"] = "710px";
            watch3.Style["position"] = "absolute";

            img4.Style["margin-left"] = "100px";
            img4.Style["position"] = "absolute";
            name4.Style["margin-left"] = "180px";
            name4.Style["position"] = "absolute";
            rate4.Style["margin-left"] = "610px";
            rate4.Style["position"] = "absolute";
            watch4.Style["margin-left"] = "710px";
            watch4.Style["position"] = "absolute";


            move(sender, e);
        }
    }
}

