﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace DB_Project
{
    public partial class post : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        // SqlConnection connection = new SqlConnection("Data Source=LAPTOP-F43KSG3P\\SERVER;Initial Catalog=iamidiot;Integrated Security=True;MultipleActiveResultSets=True");
        protected void PostButton_Click(object sender, EventArgs e)
        {






            // SqlCommand command = new SqlCommand("insert into free(fname,femail,subjectt,feedbackdesc) values ('" + txtname.Text+"','"+txtemail.Text+"','"+txtsub.Text+"','"+txtdes.Text+"')", connection);
            // connection.Open();
            //command.ExecuteNonQuery();
            // connection.Close();


            //ConfirmationLabel.Text = "Feedback added successfully!";
            //ConfirmationLabel.Visible = true;







        }

        protected void PostButton_Click1(object sender, EventArgs e)
        {




            try
            {
                // Connection string for the database
                string connectionString = "Data Source=LAPTOP-F43KSG3P\\SERVER;Initial Catalog=iamidiot;Integrated Security=True";

                // SQL query to retrieve the current maximum roll_no value
                string maxRollNoQuery = "SELECT MAX(fid) FROM feedback";

                // SQL query to insert data into the table
                //  string insertQuery = "INSERT INTO freee(fid,fname,femail,subjectt,feedbackdesc) VALUES (@fid, @fname, @femail, @subjectt, @feedbackdesc)";




                string insertQuery1 = "insert into feedback(fid,uidd,subjectt,feedbackdesc) values(@fid,@uidd, @subjectt, @feedbackdesc)";
                // Create a connection to the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Open the connection
                    connection.Open();
                    //string searchingid = "select id from ids";
                    //SqlCommand qwe = new SqlCommand(searchingid, connection);
                    //SqlDataReader r1 = qwe.ExecuteReader();
                    //r1.Read();
                    //int id = int.Parse(r1.GetValue(0).ToString());
                    //r1.Close();
                    int id = (int)Application["id"];
                    // Create a command object with the query and connection
                    SqlCommand maxRollNoCommand = new SqlCommand(maxRollNoQuery, connection);

                    // Execute the query and get the current maximum  value
                    object maxRollNo = maxRollNoCommand.ExecuteScalar();

                    // If the maximum  value is null, set it to 0
                    int nextRollNo = (maxRollNo == null || maxRollNo == DBNull.Value) ? 0 : Convert.ToInt32(maxRollNo);

                    // Increment the next roll_no value by 1
                    nextRollNo++;

                    SqlCommand insertCommand = new SqlCommand(insertQuery1, connection);

                    // Set the parameter values for the query
                    insertCommand.Parameters.AddWithValue("@fid", nextRollNo);
                    // insertCommand.Parameters.AddWithValue("@fname", txtname.Text);
                    // insertCommand.Parameters.AddWithValue("@femail", txtemail.Text);
                    insertCommand.Parameters.AddWithValue("@uidd", id);
                    insertCommand.Parameters.AddWithValue("@subjectt", txtsub.Text);
                    insertCommand.Parameters.AddWithValue("@feedbackdesc", txtdes.Text);


                    // Execute the query
                    insertCommand.ExecuteNonQuery();

                    // Close the connection
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.ToString());
            }
        }
    }
}