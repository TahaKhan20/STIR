﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class moviesdelete : System.Web.UI.Page
    {
        SqlConnection con;
        protected void move(object sender, EventArgs e)
        {
            SqlCommand q1 = new SqlCommand("Delete from movies where Mname='" + TextBox1.Text + "' AND Mdate='" + int.Parse(TextBox2.Text) + "'", con);
            q1.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Deleted')", true);

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
        }
    }
}