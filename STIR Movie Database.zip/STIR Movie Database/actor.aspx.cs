﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Data;
namespace DB_Project
{
    public partial class actor : System.Web.UI.Page
    {
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {

                BindWikiUrls();
                //  BindYouTubeVideo();
                BindImages();


                //string videoUrl = RetrieveVideoUrlFromDatabase();

                //// Set the src attribute of the iframe
                //videoFrame.Src = videoUrl;

                string iframeCode = RetrieveIframeCodeFromDatabase();

                // Set the Text property of the Literal control
                iframeContainer.Text = iframeCode;


                DataTable linkData = FetchLinkDataFromDatabase();

                // Bind the link data to a control (e.g., GridView)
                linkGridView.DataSource = linkData;
                linkGridView.DataBind();



                DataTable linkData1 = FetchLinkDataFromDatabase1();

                // Bind the link data to a control (e.g., GridView)
                GridView1.DataSource = linkData1;
                GridView1.DataBind();

                DataTable linkData2 = FetchLinkDataFromDatabase2();

                // Bind the link data to a control (e.g., GridView)
                GridView2.DataSource = linkData2;
                GridView2.DataBind();

            }
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();

            string parameterValue = Request.QueryString["id"];
            //id = int.Parse(parameterValue);
            id = 1;
            SqlCommand comm = new SqlCommand($"select * from actor where AID={id}", con);
            SqlDataReader r = comm.ExecuteReader();
            string url = string.Empty;




            if (r.Read())
            {
                l1.Text = r.GetValue(1).ToString();
                l2.Text = r.GetValue(2).ToString();
                Label1.Text = r.GetValue(11).ToString();
                Image2.ImageUrl = r.GetValue(3).ToString();
                l3.Text = r.GetValue(12).ToString();
                Label3.Text = r.GetValue(19).ToString();
                Label4.Text = r.GetValue(20).ToString();
                Label5.Text = r.GetValue(21).ToString();
                L31.Text = r.GetValue(13).ToString();

                

            }
        }


        //private string RetrieveVideoUrlFromDatabase()
        //{
        //    string videoUrl = string.Empty;
        //    string connectionString = "Data Source=LAPTOP-F43KSG3P\\SERVER;Initial Catalog=iamidiot;Integrated Security=True;MultipleActiveResultSets=True"; // Replace with your database connection string

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();

        //        // Assuming you have an ID to retrieve the video URL from the database
        //        int videoId = 3;

        //        string query = "SELECT avideo FROM actorsss WHERE aID = @VideoId";
        //        SqlCommand command = new SqlCommand(query, connection);
        //        command.Parameters.AddWithValue("@VideoId", videoId);

        //        using (SqlDataReader reader = command.ExecuteReader())
        //        {
        //            if (reader.Read())
        //            {
        //                videoUrl = reader["avideo"].ToString();
        //            }
        //        }
        //    }

        //    return videoUrl;
        //}

        private void BindImages()
        {
            // Retrieve image URLs and link URLs from the database
            DataTable imagesTable = GetImagesFromDatabase();

            // Bind the DataTable to the repeater control
            repeaterImages.DataSource = imagesTable;
            repeaterImages.DataBind();

            DataTable imagesTable1 = GetImagesFromDatabase1();
            repeater1.DataSource = imagesTable1;
            repeater1.DataBind();

            DataTable imagesTable2 = GetImagesFromDatabase2();
            repeater2.DataSource = imagesTable2;
            repeater2.DataBind();



        }


        private DataTable GetImagesFromDatabase1()
        {
            // Replace the connection string with your actual database connection string
            string connectionString = "Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True";

            // Create a new DataTable to store the image URLs and link URLs
            DataTable imagesTable1 = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Replace "YourImagesTable" with the actual table name that stores the image URLs and link URLs
                string query = $"SELECT im2, link2 FROM actor where aid={id}";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Add columns to the DataTable
                    imagesTable1.Columns.Add("im2", typeof(string));
                    imagesTable1.Columns.Add("link2", typeof(string));



                    // Iterate through the data reader and populate the DataTable
                    if (reader.Read())
                    {
                        string imageUrl = reader["im2"].ToString();
                        string linkUrl = reader["link2"].ToString();

                        // Create a new row and add the values to it
                        DataRow row = imagesTable1.NewRow();
                        row["im2"] = imageUrl;
                        row["link2"] = linkUrl;




                        //// Add the row to the Dat
                        //// aTable
                        imagesTable1.Rows.Add(row);

                    }

                    reader.Close();
                }
            }

            return imagesTable1;
        }
        private DataTable GetImagesFromDatabase2()
        {
            // Replace the connection string with your actual database connection string
            string connectionString = "Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True";

            // Create a new DataTable to store the image URLs and link URLs
            DataTable imagesTable2 = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Replace "YourImagesTable" with the actual table name that stores the image URLs and link URLs
                string query = $"SELECT im3, link3 FROM actor where aid={id}";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Add columns to the DataTable
                    imagesTable2.Columns.Add("im3", typeof(string));
                    imagesTable2.Columns.Add("link3", typeof(string));



                    // Iterate through the data reader and populate the DataTable
                    if (reader.Read())
                    {
                        string imageUrl = reader["im3"].ToString();
                        string linkUrl = reader["link3"].ToString();

                        // Create a new row and add the values to it
                        DataRow row = imagesTable2.NewRow();
                        row["im3"] = imageUrl;
                        row["link3"] = linkUrl;




                        //// Add the row to the Dat
                        //// aTable
                        imagesTable2.Rows.Add(row);

                    }

                    reader.Close();
                }
            }

            return imagesTable2;
        }
        private DataTable GetImagesFromDatabase()
        {
            // Replace the connection string with your actual database connection string
            string connectionString = "Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True";

            // Create a new DataTable to store the image URLs and link URLs
            DataTable imagesTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Replace "YourImagesTable" with the actual table name that stores the image URLs and link URLs
                string query = $"SELECT im1, link1 FROM actor where aid={id}";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Add columns to the DataTable
                    imagesTable.Columns.Add("im1", typeof(string));
                    imagesTable.Columns.Add("link1", typeof(string));



                    // Iterate through the data reader and populate the DataTable
                    if (reader.Read())
                    {
                        string imageUrl = reader["im1"].ToString();
                        string linkUrl = reader["link1"].ToString();

                        // Create a new row and add the values to it
                        DataRow row = imagesTable.NewRow();
                        row["im1"] = imageUrl;
                        row["link1"] = linkUrl;




                        //// Add the row to the Dat
                        //// aTable
                        imagesTable.Rows.Add(row);

                    }

                    reader.Close();
                }
            }

            return imagesTable;
        }
        protected void BindWikiUrls()
        {
            //string connectionString = ConfigurationManager.ConnectionStrings["Data Source=LAPTOP-F43KSG3P\\SERVER;Initial Catalog=iamidiot;Integrated Security=True;MultipleActiveResultSets=True"].ConnectionString;
            StringBuilder sb = new StringBuilder();

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True"))
            {
                connection.Open();

                string query = $"SELECT wiki FROM actor where aid={id};";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();


                if (reader.Read())
                {
                    string url = reader["wiki"].ToString();
                    sb.Append("<li><a href='" + url + "'>Visit Wikipedia</a></li>");

                }

                connection.Close();
            }

            wikiUrls.InnerHtml = sb.ToString();

        }
        //protected void BindYouTubeVideo()
        //{
        //   // string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionString"].ConnectionString;
        //    string videoUrl = string.Empty;

        //   using (SqlConnection connection = new SqlConnection("Data Source=LAPTOP-F43KSG3P\\SERVER;Initial Catalog=iamidiot;Integrated Security=True;MultipleActiveResultSets=True"))
        //    {
        //        connection.Open();

        //        string query = "SELECT Avideo FROM actorssss where aid=3;";
        //        SqlCommand command = new SqlCommand(query, connection);
        //        SqlDataReader reader = command.ExecuteReader();

        //       if(reader.Read())
        //        {
        //            videoUrl = reader["Avideo"].ToString();
        //        }

        //        connection.Close();
        //    }

        //    youtubeIframe.Attributes["src"] = videoUrl;
        //}

        private DataTable FetchLinkDataFromDatabase()
        {
            // Fetch data from the database using ADO.NET or an ORM framework like Entity Framework
            // Example using ADO.NET
            string connectionString = "Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True"; 
            string query = $"SELECT TOP 1 sid1 FROM actor where aid={id};";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable linkData = new DataTable();
                    adapter.Fill(linkData);
                    return linkData;

                }




            }
        }
        private DataTable FetchLinkDataFromDatabase1()
        {
            // Fetch data from the database using ADO.NET or an ORM framework like Entity Framework
            // Example using ADO.NET
            string connectionString = "Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True"; 
            string query = $"SELECT TOP 1 sid2 FROM actor where aid={id};";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable linkData1 = new DataTable();
                    adapter.Fill(linkData1);
                    return linkData1;

                }




            }
        }
        private DataTable FetchLinkDataFromDatabase2()
        {
            // Fetch data from the database using ADO.NET or an ORM framework like Entity Framework
            // Example using ADO.NET
            string connectionString = "Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True";
            string query = $"SELECT TOP 1 sid3 FROM actor where aid={id};";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable linkData2 = new DataTable();
                    adapter.Fill(linkData2);
                    return linkData2;

                }




            }
        }
        private string RetrieveIframeCodeFromDatabase()
        {
            string iframeCode = string.Empty;
            string connectionString = "Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Assuming you have an ID or some other criteria to retrieve the iframe code from the database
                
                string query = $"SELECT avideo FROM actor WHERE aid = {id}";
                SqlCommand command = new SqlCommand(query, connection);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        iframeCode = reader["avideo"].ToString();
                    }
                }
            }

            return iframeCode;
        }
    }
}