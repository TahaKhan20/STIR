﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace DB_Project
{
    public partial class showtimeupdate : System.Web.UI.Page
    {
        SqlConnection con;
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
        }



        protected void Button1_Click(object sender, EventArgs e)
        {

            string movieName = TextBox14.Text;

            SqlCommand command = new SqlCommand("SELECT mid FROM movies WHERE mname = @movieName", con);
            command.Parameters.AddWithValue("@movieName", movieName);

            SqlDataReader reader = command.ExecuteReader();
            int movieId = 0;
            if (reader.Read())
            {
                movieId = reader.GetInt32(0); // Assuming the `mid` column is of type INT
                                              // Use the movieId as needed
            }
            reader.Close();
            SqlCommand s23 = new SqlCommand($"Select * from showtimes where cinema='{TextBox13.Text}' AND  mid={movieId}", con);
            SqlDataReader r1 = s23.ExecuteReader();
            r1.Read();
            id = int.Parse(r1.GetValue(0).ToString());
            r1.Close();

            string name;
            string Date;
            string time;

            string city;


            if (TextBox1.Text != "")
            {
                name = (TextBox1.Text);
            }
            else
            {
                name = (r1.GetValue(1).ToString());
            }
            if (TextBox3.Text != "")
            {
                city = TextBox3.Text;
            }
            else
            {
                city = r1.GetValue(2).ToString();
            }

            if (TextBox2.Text != "")
            {
                Date = (TextBox2.Text);
            }
            else
            {
                Date = (r1.GetValue(4).ToString());
            }
            if (TextBox4.Text != "")
            {
                time = TextBox4.Text;
            }
            else
            {
                time = r1.GetValue(3).ToString();
            }




            SqlCommand s7 = new SqlCommand("UPDATE showtimes SET cinema = @name, dates = @Date, timing = @time, city = @city WHERE cinema = @existingCinema AND mid = @movieId AND timing = @existingTiming AND city = @existingCity", con);
            s7.Parameters.AddWithValue("@name", name);
            s7.Parameters.AddWithValue("@Date", Date);
            s7.Parameters.AddWithValue("@time", time);
            s7.Parameters.AddWithValue("@city", city);
            s7.Parameters.AddWithValue("@existingCinema", TextBox13.Text);
            s7.Parameters.AddWithValue("@movieId", movieId);
            s7.Parameters.AddWithValue("@existingTiming", TextBox6.Text);
            s7.Parameters.AddWithValue("@existingCity", TextBox5.Text);

            s7.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Updated');", true);
        }
    }

}