﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Data;
using System.Web.UI.HtmlControls;

namespace DB_Project
{
    public partial class recent : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {



            string connectionString = "Data Source=LAPTOP-F43KSG3P\\SERVER;Initial Catalog=iamidiot;Integrated Security=True;MultipleActiveResultSets=True";
            StringBuilder resultBuilder = new StringBuilder();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();




                string query = "SELECT userr.uname,subjectt, feedbackdesc " +
               "FROM Feedback " +
               "JOIN userr ON Feedback.uidd = userr.uidd";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string name = reader.GetString(0);
                            string data = reader.GetString(1);
                            string data2 = reader.GetString(2);

                            resultBuilder.AppendFormat("<div class=container1 ><div>{0}</div></br><div>{1}</div><div>{2}</div></br></div>", name, data, data2);

                        }
                    }
                }

            }
            Response.ContentType = "text/html";



            Response.Write("<body>");
            Response.Write("<style> body { color: white; background-color:black; font-size: large; }" +

      ".container1 { position: relative; width: 396px; height: 100px; background-color: #222; " +
      "border-radius: 10px; padding: 50px 50px; box-shadow: -3px -3px 9px #aaa9a9a2, 3px 3px 7px rgba(147, 149, 151, 0.671); }" +
      ".container1:nth-child(odd) { top: 27%; left: 10%; }" +
      ".container1:nth-child(even) { top: 14%; left: 60%; }" +
      ".stir { font-size: 60px; color: white; margin-top: 0%; margin-bottom: 0%; text-align: center; padding: 10px; }" +
      ".topnav { overflow: hidden; background-color: #222; }" +
      ".topnav a { float: left; color: #f2f2f2; text-align: center; padding: 12px 18px; text-decoration: none; font-size: 20px; }" +
      ".topnav a:hover { background-color: #555; border-radius: 6px; }" +
      "@media screen and (max-height: 500px) { .topnav a { padding: 9px 12px; font-size: 19px; } }" +
      "@media screen and (max-height: 400px) { .topnav a { padding: 6px 6px; font-size: 18px; } }" +
      "footer { position:absolute;display: block; color: rgb(20, 20, 20); margin-top: 3px; padding: 2% 6% 0% 6%; border-radius: 5px; }" +
      ".f { display: flex; margin-top: 12px; }" +
      ".ft { margin: 4px 0px; display: block; padding: 1% 6%; background-color: rgb(23, 23, 23); margin-left: 10.5%; border-radius: 20px; }" +
      ".ft h1 { font-size: 22px; }" +
      ".ft p { margin: 2.5% 0%; margin-left: 6%; font-size: 18px; }" +
      ".ft a { color: #ccc; font-size: 18px; }" +
      ".btn { margin-left: 40%; background-color: rgb(40, 40, 40); color: rgb(10, 100, 200); font-size: 19px; padding: 8px 16px; border-radius: 5px; font-family: Calibri; border: 1.5px solid #111; cursor: pointer; }" +
      ".dropdown { float: left; overflow: hidden; }" +
      ".dropdown:hover { background-color: #555; border-radius: 6px; }" +
      ".dropbtn { font-size: 20px; border: inherit; color: #f2f2f2; background-color: inherit; font-family: inherit; padding: 12px 18px; cursor: pointer; }" +
      ".dropdown-content { display: none; position: absolute; background-color: #222; }" +
      ".dropdown-content a:hover { background-color: #555; z-index: 9999; }" +
      ".dropdown:hover .dropdown-content { display: block; }" +
      ".stage {height: 200px; overflow: hidden; position: relative; width: 100vw;}" +
            ".dropdown-content a { float: none; display: block; justify-content: center; font-size: 20px; color: #f2f2f2; padding: 15px 25px; }" +
      ".actor { animation: kenburns 30s linear infinite; background-size: cover; background-position: 50%; height: 200px; inset: 0; opacity: 0; position: absolute; scale: 1.2; width: 93vw; }" +
      ".actor:nth-child(1) { background-image: url('https://images.squarespace-cdn.com/content/v1/5425e769e4b0f1b39f8abfd9/1412358459724-T1VCX04ZZUTBQV03JH0K/movies.jpg?format=1000w'); }" +
      ".actor:nth-child(2) { animation-delay: 10s; background-image: url('https://media.wired.co.uk/photos/606da399ef7fc50463192e36/master/w_1280,c_limit/lovefilm-copy.jpg'); }" +
      ".actor:nth-child(3) { animation-delay: 20s; background-image: url('https://store-images.s-microsoft.com/image/apps.15171.14253076346048674.45065d9c-1d6c-45c1-9c28-b43191c222f9.a7d3c572-cd5f-4663-bc09-cb8af2495738?mode=scale&q=90&h=1080&w=1920'); }" +
      "</style>");

            Response.Write(@"
    <div class='stage'><div class='actor'></div><div class='actor'></div><div class='actor'></div></div>
    <p class='stir'>STIR</p>
    <p style='margin-top:-10px; margin-bottom:5px; font-size:20px; text-align:center;color:white;'>Movie Database System</p>
    <br />
    <div class='topnav'>
        <a href='https://localhost:44320/homepage.aspx'>Home</a>
        <div class='dropdown'>
            <button type='button' class='dropbtn' onclick=""location.href='https://localhost:44320/movies.aspx';"">Movies</button>
            <div class='dropdown-content'>
                <a href='#trending'>Trending</a>
                <a href='#upcoming'>Upcoming</a>
                <a href='#popular'>Popular</a>
            </div>
        </div>
        <div class='dropdown'>
            <button type='button' class='dropbtn' onclick=""location.href='https://localhost:44320/seasons.aspx';"">Seasons</button>
            <div class='dropdown-content'>
                <a href='#trending'>Trending</a>
                <a href='#upcoming'>Upcoming</a>
                <a href='#popular'>Popular</a>
            </div>
        </div>
        <a href='https://localhost:44320/showtime.aspx'>Showtimes</a>
        <a href='https://localhost:44320/oscars.aspx'>Awards</a>
        <a href='https://localhost:44320/feedback.aspx'>Feedback</a>
        <div class='dropdown'>
            <button type='button' class='dropbtn' onclick=""location.href='https://localhost:44320/celebrities.aspx';"">Celebrities</button>
            <div class='dropdown-content'>
                <a href='https://localhost:44320/actors.aspx'>Actors</a>
                <a href='https://localhost:44320/directors.aspx'>Directors</a>
            </div>
        </div>
        <a href='https://localhost:44320/about.aspx'>About</a>
        <a href='https://localhost:44320/watchlist.aspx'>Watchlist</a>
        <a href='https://localhost:44320/login.aspx' style='float:right'>Sign In</a>
        <a href='https://localhost:44320/premium.aspx' style='float:right'><b>STIR<strong style='color:#02b4e6'>Pro</strong></b></a>
    </div>

    
");

            // Return the HTML result to the AJAX request
            Response.Write(resultBuilder.ToString());

            Response.Write("</body>");


            Response.End();

        }

    }

}