﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class Actors1 : System.Web.UI.Page
    {
        public static int dval1 = 1;
        public static int dval2 = 2;
        public static int dval3 = 3;
         int val1 = 1;
        int val2 = 2;
        int val3 = 3;
        public static int i = 0;
        public static int j = 0;
        int count = 0;
        int Count = 0;
        string move;
        string move1;
        string move2;
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();

            SqlCommand id1 = new SqlCommand("select AID from actor", con);
            SqlDataReader idr = id1.ExecuteReader();
            idr.Read();
            string ids = idr.GetValue(0).ToString();
            int id = int.Parse(ids);
            

            SqlCommand comm = new SqlCommand("select * from actors", con);
            SqlCommand com = new SqlCommand("select count(*) from actors", con);
            SqlDataReader r = comm.ExecuteReader();
            SqlDataReader c = com.ExecuteReader();
            c.Read();
            string co = c.GetValue(0).ToString();
            count = int.Parse(co);
            int x = 0;
            if (count % 3 != 0)
            {
                count = (3 - count % 3) + count;
            }
            while (x < i)
            {
                r.Read();
                x++;
            }
            if (x < count)
            {
                if (r.Read())
                {
                    name0.Text = r.GetValue(1).ToString();
                    des0.Text = r.GetValue(2).ToString();
                    act0.ImageUrl = r.GetValue(3).ToString();
                    name0.Visible = true;
                    des0.Visible = true;
                    act0.Visible = true;
                    box01.Style["visibility"] = "visibility";
                  
                }
                else
                {
                    name0.Visible = false;
                    des0.Visible = false;
                    act0.Visible = false;
                    box01.Style["visibility"] = "hidden";
                }
                if (r.Read())
                {
                    name1.Text = r.GetValue(1).ToString();
                    des1.Text = r.GetValue(2).ToString();
                    act1.ImageUrl = r.GetValue(3).ToString();
                    name1.Visible = true;
                    des1.Visible = true;
                    act1.Visible = true;
                    box02.Style["visibility"] = "visibility";
                   
                }
                else
                {
                    name1.Visible = false;
                    des1.Visible = false;
                    act1.Visible = false;
                    box02.Style["visibility"] = "hidden";
                }
                if (r.Read())
                {
                    name2.Text = r.GetValue(1).ToString();
                    des2.Text = r.GetValue(2).ToString();
                    act2.ImageUrl = r.GetValue(3).ToString();
                    name2.Visible = true;
                    des2.Visible = true;
                    act2.Visible = true;
                    box03.Style["visibility"] = "visible";
                 
                }
                else
                {
                    name2.Visible = false;
                    des2.Visible = false;
                    act2.Visible = false;
                    box03.Style["visibility"] = "hidden";
                }
            }
            else
            {
                over1.Style["visibility"] = "hidden";
                box01.Style["visibility"] = "hidden";
                box02.Style["visibility"] = "hidden";
                box03.Style["visibility"] = "hidden";
            }
            
            move = $"http://localhost:44320/actor.aspx?i={id}";
            link1.Text= $"<a href=\"{move}\">see more</a>";
            //move1 = $"http://localhost:44320/actor.aspx?id={}";
            //link2.Text = $"<a href=\"{move1}\">see more</a>";
            //move2 = $"http://localhost:44320/actor.aspx?id={val3}";
            //link3.Text = $"<a href=\"{move2}\">see more</a>";


            SqlConnection con1 = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con1.Open();
            SqlCommand Comm = new SqlCommand("select * from directors", con1);
            SqlCommand Com = new SqlCommand("select count(*) from directors", con1);
            SqlDataReader R = Comm.ExecuteReader();
            SqlDataReader C = Com.ExecuteReader();
            C.Read();
            string Co = C.GetValue(0).ToString();
            Count = int.Parse(Co);
            int X = 0;
            if (Count % 3 != 0)
            {
                Count = (3 - Count % 3) + Count;
            }
            while (X < j)
            {
                R.Read();
                X++;
            }
            if (X < Count)
            {
                if (R.Read())
                {
                    dname0.Text = R.GetValue(1).ToString();
                    ddes0.Text = R.GetValue(2).ToString();
                    dimage0.ImageUrl = R.GetValue(3).ToString();
                    dname0.Visible = true;
                    ddes0.Visible = true;
                    dimage0.Visible = true;
                    box1.Style["visibility"] = "visible";
                }
                else
                {
                    dname0.Visible = false;
                    ddes0.Visible = false;
                    dimage0.Visible = false;
                    box1.Style["visibility"] = "hidden";
                }
                if (R.Read())
                {
                    dname1.Text = R.GetValue(1).ToString();
                    ddes1.Text = R.GetValue(2).ToString();
                    dimage1.ImageUrl = R.GetValue(3).ToString();
                    dname1.Visible = true;
                    ddes1.Visible = true;
                    dimage1.Visible = true;
                    box2.Style["visibility"] = "visible";
                }
                else
                {
                    dname1.Visible = false;
                    ddes1.Visible = false;
                    dimage1.Visible = false;
                    box2.Style["visibility"] = "hidden";
                }
                if (R.Read())
                {
                    dname2.Text = R.GetValue(1).ToString();
                    ddes2.Text = R.GetValue(2).ToString();
                    dimage2.ImageUrl = R.GetValue(3).ToString();
                    dname2.Visible = true;
                    ddes2.Visible = true;
                    dimage2.Visible = true;
                    box3.Style["visibility"] = "visible";
                }
                else
                {
                    dname2.Visible = false;
                    ddes2.Visible = false;
                    dimage2.Visible = false;
                    box3.Style["visibility"] = "hidden";
                }
            }
            else
            {
                over2.Style["visibility"] = "hidden";
                box1.Style["visibility"] = "hidden";
                box2.Style["visibility"] = "hidden";
                box3.Style["visibility"] = "hidden";
            }

            //move = $"http://localhost:44320/director.aspx?id={dval1}";
            //dlink1.Text = $"<a href=\"{move}\">see more</a>";
            //move1 = $"http://localhost:44320/director.aspx?id={dval2}";
            //dlink2.Text = $"<a href=\"{move1}\">see more</a>";
            //move2 = $"http://localhost:44320/director.aspx?id={dval3}";
            //dlink3.Text = $"<a href=\"{move2}\">see more</a>";

        }
        protected void Nextclick(object sender, EventArgs e)
        {
            i += 3;
            if (i >= count)
            {
                i = 0;
            }
            val1 = i + 1;
            val2 = i + 2;
            val3 = i + 3;
            move = $"http://localhost:44320/actor.aspx?id={val1}";
            link1.Text = $"<a href=\"{move}\">see more</a>";
            move1 = $"http://localhost:44320/actor.aspx?id={val2}";
            link2.Text = $"<a href=\"{move1}\">see more</a>";
            move2 = $"http://localhost:44320/actor.aspx?id={val3}";
            link3.Text = $"<a href=\"{move2}\">see more</a>";

            Page_Load(sender, e);
        }
        protected void Prevclick(object sender, EventArgs e)
        {

            i -= 3;
            if (i < 0)
            {
                i = count - 3;
                if (count % 3 != 0)
                {
                    i = i + count % 3;
                }
            }
            val1 = i + 1;
            val2 = i + 2;
            val3 = i + 3;
            move = $"http://localhost:44320/actor.aspx?id={val1}";
            link1.Text = $"<a href=\"{move}\">see more</a>";
            move1 = $"http://localhost:44320/actor.aspx?id={val2}";
            link2.Text = $"<a href=\"{move1}\">see more</a>";
            move2 = $"http://localhost:44320/actor.aspx?id={val3}";
            link3.Text = $"<a href=\"{move2}\">see more</a>";

            Page_Load(sender, e);
        }
        protected void NextDir(object sender, EventArgs e)
        {
            j = j + 3;

            if (j >= Count)
            {
                j = 0;
            }
            dval1 = j + 1;
            dval2 = j + 2;
            dval3 = j + 3;
            move = $"http://localhost:44320/director.aspx?id={dval1}";
            dlink1.Text = $"<a href=\"{move}\">see more</a>";
            move1 = $"http://localhost:44320/director.aspx?id={dval2}";
            dlink2.Text = $"<a href=\"{move1}\">see more</a>";
            move2 = $"http://localhost:44320/director.aspx?id={dval3}";
            dlink3.Text = $"<a href=\"{move2}\">see more</a>";


            Page_Load(sender, e);
        }
        protected void PrevDir(object sender, EventArgs e)
        {
            j = j - 3;

            if (j < 0)
            {
                j = Count - 3;
                if (Count % 3 != 0)
                {
                    j = j + Count % 3;
                }
            }
            dval1 = j + 1;
            dval2 = j + 2;
            dval3 = j + 3;
            move = $"http://localhost:44320/director.aspx?id={dval1}";
            dlink1.Text = $"<a href=\"{move}\">see more</a>";
            move1 = $"http://localhost:44320/director.aspx?id={dval2}";
            dlink2.Text = $"<a href=\"{move1}\">see more</a>";
            move2 = $"http://localhost:44320/director.aspx?id={dval3}";
            dlink3.Text = $"<a href=\"{move2}\">see more</a>";


            Page_Load(sender, e);
        }
    }
}