﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class Homepage : System.Web.UI.Page
    {
        public static int i = 0;
        public static int j = 0;
        int count = 0;
        int count1 = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
            SqlCommand movies = new SqlCommand("select * from movies",con);
            SqlDataReader r = movies.ExecuteReader();
            

            SqlCommand com = new SqlCommand("select count(*) from movies", con);
            SqlDataReader c = com.ExecuteReader();
            c.Read();
            string co = c.GetValue(0).ToString();
            count = int.Parse(co);
            int x = 0;
            string url = " ";
            string aimg1 = " ";
            while (x < i)
            {
                r.Read();
                x++;
            }
            if (x < count)
            {
                if (r.Read())
                {
                    string ids = r.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r.GetValue(6).ToString();
                    
                    url = $"https://localhost:44320/movies-des.aspx?i={id}";
                    m1.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    m1.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }
                if (r.Read())
                {
                    string ids = r.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r.GetValue(6).ToString();

                    url = $"https://localhost:44320/movies-des.aspx?i={id}";
                    m2.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    m2.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }
                if (r.Read())
                {
                    string ids = r.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r.GetValue(6).ToString();

                    url = $"https://localhost:44320/movies-des.aspx?i={id}";
                    m3.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    m3.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }
                if (r.Read())
                {
                    string ids = r.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r.GetValue(6).ToString();

                    url = $"https://localhost:44320/movies-des.aspx?i={id}";
                    m4.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    m4.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }
                if (r.Read())
                {
                    string ids = r.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r.GetValue(6).ToString();

                    url = $"https://localhost:44320/movies-des.aspx?i={id}";
                    m5.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    m5.Text = $"<a href=\"{url}\"><img class=\"movies\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }

            }

            SqlCommand seasons = new SqlCommand("select * from seasons", con);
            SqlDataReader r1 = seasons.ExecuteReader();


            SqlCommand com1 = new SqlCommand("select count(*) from seasons", con);
            SqlDataReader c1 = com1.ExecuteReader();
            c1.Read();
            string co1 = c1.GetValue(0).ToString();
            count1 = int.Parse(co1);
            int X = 0;

            while (X < j)
            {
                r1.Read();
                X++;
            }
            if (X < count1)
            {

                if (r1.Read())
                {
                    string ids = r1.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r1.GetValue(6).ToString();

                    url = $"https://localhost:44320/seasons.aspx?i={id}";
                    s1.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    s1.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }
                if (r1.Read())
                {
                    string ids = r1.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r1.GetValue(6).ToString();

                    url = $"https://localhost:44320/seasons.aspx?i={id}";
                    s2.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    s2.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }
                if (r1.Read())
                {
                    string ids = r1.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r1.GetValue(6).ToString();

                    url = $"https://localhost:44320/seasons.aspx?i={id}";
                    s3.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    s3.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }
                if (r1.Read())
                {
                    string ids = r1.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r1.GetValue(6).ToString();

                    url = $"https://localhost:44320/seasons.aspx?i={id}";
                    s4.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    s4.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }
                if (r1.Read())
                {
                    string ids = r1.GetValue(0).ToString();
                    int id = int.Parse(ids);

                    aimg1 = r1.GetValue(6).ToString();

                    url = $"https://localhost:44320/seasons.aspx?i={id}";
                    s5.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:Visible\" src=\"{aimg1}\" ></img></a>";

                }
                else
                {
                    s5.Text = $"<a href=\"{url}\"><img class=\"seasons\" style=\"visibility:hidden\" src=\"{aimg1}\" ></img></a>";

                }


            }

        }
        protected void Nextclick(object sender, EventArgs e)
        {
            i += 5;
            if (i >= count)
            {
                i = 0;
            }
            
            Page_Load(sender, e);
        }
        protected void Prevclick(object sender, EventArgs e)
        {

            i -= 5;
            if (i < 0)
            {
                i = count - count % 5;
            }
            
            Page_Load(sender, e);
        }

        protected void NextDir(object sender, EventArgs e)
        {
            j += 5;
            if (j >= count)
            {
                j = 0;
            }

            Page_Load(sender, e);
        }
        protected void PrevDir(object sender, EventArgs e)
        {

            j -= 5;
            if (j < 0)
            {
                j = count - count % 5;
            }

            Page_Load(sender, e);
        }
    }
}