﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class awards : System.Web.UI.Page
    {

        public static int i = 0;
        public static int j = 0;
        public static int k = 0;
        
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;

        protected void Page_Load(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
            SqlCommand comm = new SqlCommand("select * from aawards join actors on actors.aid=aawards.AID", con);
            SqlCommand com = new SqlCommand("select count(*) from aawards join actors on actors.aid=aawards.AID", con);
            SqlDataReader R = comm.ExecuteReader();
            SqlDataReader c = com.ExecuteReader();
            c.Read();
            string co = c.GetValue(0).ToString();
            count2 = int.Parse(co);
            int x = 0;
            if (count2 % 3 != 0)
            {
                count2 = (3 - count2 % 3) + count2;
            }
            while (x < j)
            {
                R.Read();
                x++;
            }
            if (x < count2)
            {
                if (R.Read())
                {

                    a0.ImageUrl = R.GetValue(11).ToString();
                    //event0.Text = R.GetValue(4).ToString();
                    acat0.Text = R.GetValue(5).ToString();
                    aname0.Text = R.GetValue(2).ToString();
                    mname0.Text = R.GetValue(6).ToString();
                    a0.Visible = true;
                    //event0.Visible = true;
                    acat0.Visible = true;
                    aname0.Visible = true;
                    mname0.Visible = true;
                    box4.Style["visibility"] = "visibility";

                }
                else
                {
                    a0.Visible = false;
                    //event0.Visible = false;
                    acat0.Visible = false;
                    aname0.Visible = false;
                    mname0.Visible = false;
                    box4.Style["visibility"] = "hidden";
                }
                if (R.Read())
                {

                    a1.ImageUrl = R.GetValue(11).ToString();
                    //event0.Text = R.GetValue(4).ToString();
                    acat1.Text = R.GetValue(5).ToString();
                    aname1.Text = R.GetValue(2).ToString();
                    mname1.Text = R.GetValue(6).ToString();
                    m1.Visible = true;
                    //event0.Visible = true;
                    acat1.Visible = true;
                    aname1.Visible = true;
                    mname1.Visible = true;
                    box5.Style["visibility"] = "visibility";

                }
                else
                {
                    a1.Visible = false;
                    //event0.Visible = false;
                    acat1.Visible = false;
                    aname1.Visible = false;
                    mname1.Visible = false;
                    box5.Style["visibility"] = "hidden";
                }
                if (R.Read())
                {

                    a2.ImageUrl = R.GetValue(11).ToString();
                    //event0.Text = R.GetValue(4).ToString();
                    acat2.Text = R.GetValue(5).ToString();
                    aname2.Text = R.GetValue(2).ToString();
                    mname2.Text = R.GetValue(6).ToString();
                    a2.Visible = true;
                    //event0.Visible = true;
                    acat2.Visible = true;
                    aname2.Visible = true;
                    mname2.Visible = true;
                    box6.Style["visibility"] = "visibility";

                }
                else
                {
                    a2.Visible = false;
                    //event0.Visible = false;
                    acat2.Visible = false;
                    aname2.Visible = false;
                    mname2.Visible = false;
                    box6.Style["visibility"] = "hidden";
                }
            }
            else
            {
                box4.Style["visibility"] = "hidden";
                box5.Style["visibility"] = "hidden";
                box6.Style["visibility"] = "hidden";
            }

            SqlCommand COMM = new SqlCommand("select * from dawards join directors on directors.DID=dawards.did", con);
            SqlCommand COM = new SqlCommand("select count(*) from dawards join directors on directors.DID=dawards.did", con);
            SqlDataReader R1 = COMM.ExecuteReader();
            SqlDataReader C1 = COM.ExecuteReader();
            C1.Read();
            string CO1 = C1.GetValue(0).ToString();
            count3 = int.Parse(CO1);
            int X1 = 0;
            if (count3 % 3 != 0)
            {
                count3 = (3 - count3 % 3) + count3;
            }
            while (X1 < k)
            {
                R1.Read();
                X1++;
            }
            if (X1 < count3)
            {
                if (R1.Read())
                {

                    d0.ImageUrl = R1.GetValue(11).ToString();
                    //event0.Text = R.GetValue(4).ToString();
                    dcat0.Text = R1.GetValue(5).ToString();
                    dname0.Text = R1.GetValue(2).ToString();
                    dmname0.Text = R1.GetValue(6).ToString();
                    d0.Visible = true;
                    //event0.Visible = true;
                    dcat0.Visible = true;
                    dname0.Visible = true;
                    dmname0.Visible = true;
                    box7.Style["visibility"] = "visibility";

                }
                else
                {
                    d0.Visible = false;
                    //event0.Visible = false;
                    dcat0.Visible = false;
                    dname0.Visible = false;
                    dmname0.Visible = false;
                    box7.Style["visibility"] = "hidden";
                }
                if (R1.Read())
                {

                    d1.ImageUrl = R1.GetValue(11).ToString();
                    //event0.Text = R.GetValue(4).ToString();
                    dcat1.Text = R1.GetValue(5).ToString();
                    dname1.Text = R1.GetValue(2).ToString();
                    dmname1.Text = R1.GetValue(6).ToString();
                    d1.Visible = true;
                    //event0.Visible = true;
                    dcat1.Visible = true;
                    dname1.Visible = true;
                    dmname1.Visible = true;
                    box8.Style["visibility"] = "visibility";

                }
                else
                {
                    d1.Visible = false;
                    //event0.Visible = false;
                    dcat1.Visible = false;
                    dname1.Visible = false;
                    dmname1.Visible = false;
                    box8.Style["visibility"] = "hidden";
                }
                if (R1.Read())
                {

                    d2.ImageUrl = R1.GetValue(11).ToString();
                    //event0.Text = R.GetValue(4).ToString();
                    dcat2.Text = R1.GetValue(5).ToString();
                    dname2.Text = R1.GetValue(2).ToString();
                    dmname2.Text = R1.GetValue(6).ToString();
                    d2.Visible = true;
                    //event0.Visible = true;
                    dcat2.Visible = true;
                    dname2.Visible = true;
                    dmname2.Visible = true;
                    box9.Style["visibility"] = "visibility";

                }
                else
                {
                    d2.Visible = false;
                    //event0.Visible = false;
                    dcat2.Visible = false;
                    dname2.Visible = false;
                    dmname2.Visible = false;
                    box9.Style["visibility"] = "hidden";
                }
            }
            else
            {
                box7.Style["visibility"] = "hidden";
                box8.Style["visibility"] = "hidden";
                box9.Style["visibility"] = "hidden";
            }

            SqlCommand Comm = new SqlCommand("select * from movieawards join movies on movies.MID=movieawards.MID", con);
            SqlCommand Com = new SqlCommand("select count(*) from movieawards join movies on movies.MID=movieawards.MID", con);
            R = Comm.ExecuteReader();
            SqlDataReader C = Com.ExecuteReader();
            C.Read();
            string Co = C.GetValue(0).ToString();
            count1 = int.Parse(Co);
            int X = 0;
            if (count1 % 3 != 0)
            {
                count1 = (3 - count1 % 3) + count2;
            }
            while (X < i)
            {
                R.Read();
                X++;
            }
            if (X < count1)
            {
                if (R.Read())
                {
                    m0.ImageUrl = R.GetValue(12).ToString();
                    event0.Text = R.GetValue(4).ToString();
                    year0.Text = R.GetValue(3).ToString();
                    movie0.Text = R.GetValue(2).ToString();
                    m0.Visible = true;
                    event0.Visible = true;
                    year0.Visible = true;
                    box1.Style["visibility"] = "visible";
                }
                else
                {
                    movie0.Visible = false;
                    m0.Visible = false;
                    event0.Visible = false;
                    year0.Visible = false; 
                    box1.Style["visibility"] = "hidden";
                }
                if (R.Read())
                {
                    m1.ImageUrl = R.GetValue(12).ToString();
                    event1.Text = R.GetValue(4).ToString();
                    year1.Text = R.GetValue(3).ToString();

                    movie1.Text = R.GetValue(2).ToString();
                    m1.Visible = true;
                    event1.Visible = true;
                    year1.Visible = true;
                    box2.Style["visibility"] = "visible";
                }
                else
                {
                    m1.Visible = false;
                    event1.Visible = false;
                    year1.Visible = false;
                    box2.Style["visibility"] = "hidden";
                }
                if (R.Read())
                {
                    m2.ImageUrl = R.GetValue(12).ToString();
                    event2.Text = R.GetValue(4).ToString();
                    year2.Text = R.GetValue(3).ToString();
                    movie2.Text = R.GetValue(2).ToString();
                    m2.Visible = true;
                    event2.Visible = true;
                    year2.Visible = true;
                    box3.Style["visibility"] = "visible";
                }
                else
                {
                    m2.Visible = false;
                    event2.Visible = false;
                    year2.Visible = false;
                    box3.Style["visibility"] = "hidden";
                }
            }
            else
            {
                box1.Style["visibility"] = "hidden";
                box2.Style["visibility"] = "hidden";
                box3.Style["visibility"] = "hidden";
            }

        }
        protected void Nextclick1(object sender, EventArgs e)
        {
            i += 3;
            if (i >= count1)
            {
                i = 0;
            }

            Page_Load(sender, e);
        }
        protected void Prevclick1(object sender, EventArgs e)
        {

            i -= 3;
            if (i < 0)
            {
                i = count1 - 3;
                if (count1 % 3 != 0)
                {
                    i = i + count1 % 3;
                }
            }

            Page_Load(sender, e);
        }
        protected void Nextclick2(object sender, EventArgs e)
        {
            j += 3;
            if (j >= count2)
            {
                j = 0;
            }

            Page_Load(sender, e);
        }
        protected void Prevclick2(object sender, EventArgs e)
        {

            j -= 3;
            if (j < 0)
            {
                j = count2 - 3;
                if (count2 % 3 != 0)
                {
                    j = j + count2 % 3;
                }
            }

            Page_Load(sender, e);
        }

        protected void Nextclick3(object sender, EventArgs e)
        {
            k += 3;
            if (k >= count3)
            {
                k = 0;
            }

            Page_Load(sender, e);
        }
        protected void Prevclick3(object sender, EventArgs e)
        {

            k -= 3;
            if (k < 0)
            {
                k = count3 - 3;
                if (count3 % 3 != 0)
                {
                    k = k + count3 % 3;
                }
            }

            Page_Load(sender, e);
        }

    }
}