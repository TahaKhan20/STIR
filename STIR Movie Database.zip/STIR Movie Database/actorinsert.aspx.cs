﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace DB_Project
{
    public partial class actorinsert : System.Web.UI.Page
    {
        SqlConnection con;

        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
            // move1(sender, e);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand q2 = new SqlCommand("Select MAX(aid) from actorssss", con);
            SqlDataReader r1 = q2.ExecuteReader();
            r1.Read();
            int newid = int.Parse(r1.GetValue(0).ToString());
            newid = ++newid;
            r1.Close();
            //SqlCommand q1 = new SqlCommand($"Insert into actorssss values({newid},'" + txtdes.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox9.Text + "','" + TextBox10.Text + "','','" + TextBox11.Text + "','" + TextBox8.Text + "','" + TextBox7.Text + "','" + TextBox6.Text + "','" + TextBox12.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "' , '" + int.Parse(TextBox13.Text) + "','" + TextBox14.Text + "','" + TextBox15.Text + "','" + TextBox16.Text + "','" + TextBox17.Text + "','" + TextBox18.Text + "','" + TextBox19.Text + "','" + TextBox20.Text + "')", con);
            //q1.ExecuteNonQuery();
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);


            //SqlCommand q4 = new SqlCommand($"Insert into aextra values({newid},'" + TextBox21.Text + "','" + TextBox22.Text + "','" + TextBox23.Text + "','" + (TextBox24.Text) + "','" + TextBox25.Text + "','" + TextBox26.Text + "','" + (TextBox27.Text) + "','" + TextBox28.Text + "','" + TextBox29.Text + "' ,'" + TextBox30.Text + "')", con);
            //q4.ExecuteNonQuery();





            //ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);
            SqlCommand q1 = new SqlCommand("INSERT INTO actor VALUES (@newid, @txtdes, @TextBox1, @TextBox2, @TextBox3, @TextBox9, @TextBox10, @TextBox11, @TextBox8, @TextBox7, @TextBox6, @TextBox12, @TextBox4, @TextBox5, @TextBox13, @TextBox14, @TextBox15, @TextBox16, @TextBox17, @TextBox18, @TextBox19, @TextBox20)", con);
            q1.Parameters.AddWithValue("@newid", newid);
            q1.Parameters.AddWithValue("@txtdes", txtdes.Text);
            q1.Parameters.AddWithValue("@TextBox1", TextBox1.Text);
            q1.Parameters.AddWithValue("@TextBox2", TextBox2.Text);
            q1.Parameters.AddWithValue("@TextBox3", TextBox3.Text);
            q1.Parameters.AddWithValue("@TextBox9", TextBox9.Text);
            q1.Parameters.AddWithValue("@TextBox10", TextBox10.Text);
            q1.Parameters.AddWithValue("@TextBox11", TextBox11.Text);
            q1.Parameters.AddWithValue("@TextBox8", TextBox8.Text);
            q1.Parameters.AddWithValue("@TextBox7", TextBox7.Text);
            q1.Parameters.AddWithValue("@TextBox6", TextBox6.Text);
            q1.Parameters.AddWithValue("@TextBox12", TextBox12.Text);
            q1.Parameters.AddWithValue("@TextBox4", TextBox4.Text);
            q1.Parameters.AddWithValue("@TextBox5", TextBox5.Text);
            q1.Parameters.AddWithValue("@TextBox13", int.Parse(TextBox13.Text));
            q1.Parameters.AddWithValue("@TextBox14", TextBox14.Text);
            q1.Parameters.AddWithValue("@TextBox15", TextBox15.Text);
            q1.Parameters.AddWithValue("@TextBox16", TextBox16.Text);
            q1.Parameters.AddWithValue("@TextBox17", TextBox17.Text);
            q1.Parameters.AddWithValue("@TextBox18", TextBox18.Text);
            q1.Parameters.AddWithValue("@TextBox19", TextBox19.Text);
            q1.Parameters.AddWithValue("@TextBox20", TextBox20.Text);
            q1.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);

            SqlCommand q4 = new SqlCommand("INSERT INTO aextra VALUES (@newid, @TextBox21, @TextBox22, @TextBox23, @TextBox24, @TextBox25, @TextBox26, @TextBox27, @TextBox28, @TextBox29, @TextBox30)", con);
            q4.Parameters.AddWithValue("@newid", newid);
            q4.Parameters.AddWithValue("@TextBox21", TextBox21.Text);
            q4.Parameters.AddWithValue("@TextBox22", TextBox22.Text);
            q4.Parameters.AddWithValue("@TextBox23", TextBox23.Text);
            q4.Parameters.AddWithValue("@TextBox24", TextBox24.Text);
            q4.Parameters.AddWithValue("@TextBox25", TextBox25.Text);
            q4.Parameters.AddWithValue("@TextBox26", TextBox26.Text);
            q4.Parameters.AddWithValue("@TextBox27", TextBox27.Text);
            q4.Parameters.AddWithValue("@TextBox28", TextBox28.Text);
            q4.Parameters.AddWithValue("@TextBox29", TextBox29.Text);
            q4.Parameters.AddWithValue("@TextBox30", TextBox30.Text);
            q4.ExecuteNonQuery();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);

        }
    }
}