﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class awardsinsert : System.Web.UI.Page
    {
        SqlConnection con;

        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
            // move1(sender, e);
        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand q2 = new SqlCommand("Select MAX(awid) from aawards", con);
            SqlDataReader r1 = q2.ExecuteReader();
            r1.Read();
            int newawid = int.Parse(r1.GetValue(0).ToString());
            newawid = ++newawid;
            r1.Close();
            SqlCommand q1 = new SqlCommand("INSERT INTO aawards VALUES (@newaid, @aid, @aname, @ayear, @aevent, @acategory, @amovie, @amid)", con);
            q1.Parameters.AddWithValue("@newaid", newawid);

            SqlCommand a3 = new SqlCommand("select aid from actor where Aname=@aname", con);
            a3.Parameters.AddWithValue("@aname", aname.Text);
            SqlDataReader p3 = a3.ExecuteReader();
            p3.Read();
            string id3 = p3.GetValue(0).ToString();
            int aid = int.Parse(id3);
            q1.Parameters.AddWithValue("@aid", aid);

            q1.Parameters.AddWithValue("@aname", aname.Text);
            q1.Parameters.AddWithValue("@ayear", ayear.Text);
            q1.Parameters.AddWithValue("@aevent", aevent.Text);
            q1.Parameters.AddWithValue("@acategory", acategory.Text);
            q1.Parameters.AddWithValue("@amovie", amovie.Text);

            SqlCommand a2 = new SqlCommand("select mid from movies where Mname=@mname", con);
            a2.Parameters.AddWithValue("@mname", amovie.Text);
            SqlDataReader p2 = a2.ExecuteReader();
            int amid = 0;
            if (p2.Read())
            {
                string id2 = p2.GetValue(0).ToString();
                amid = int.Parse(id2);
            }
            q1.Parameters.AddWithValue("@amid", amid);

            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlCommand q = new SqlCommand("Select MAX(dwid) from dawards", con);
            SqlDataReader r = q.ExecuteReader();
            r.Read();
            int newdwid = int.Parse(r.GetValue(0).ToString());
            newdwid = ++newdwid;
            SqlCommand q4 = new SqlCommand("INSERT INTO dawards VALUES @newdwid, @did, @dname, @dyear, @devent, @dcategory, @dmovie, @dmid)", con);
            q4.Parameters.AddWithValue("@newdwid", newdwid);
            q4.Parameters.AddWithValue("@dname", dname.Text);

            SqlCommand a4 = new SqlCommand("select did from director where Dname=@dname", con);
            a4.Parameters.AddWithValue("@aname", aname.Text);
            SqlDataReader p4 = a4.ExecuteReader();
            p4.Read();
            string id4 = p4.GetValue(0).ToString();
            int did = int.Parse(id4);
            q4.Parameters.AddWithValue("@did", did);

            q4.Parameters.AddWithValue("@dyear", dyear.Text);
            q4.Parameters.AddWithValue("@devent", devent.Text);
            q4.Parameters.AddWithValue("@dcategory", dcategory.Text);
            q4.Parameters.AddWithValue("@dmovie", dmovie.Text);
            SqlCommand a1 = new SqlCommand("select mid from movies where Mname=@mname", con);
            a1.Parameters.AddWithValue("@mname", mname.Text);
            SqlDataReader p1 = a1.ExecuteReader();
            p1.Read();
            string id1 = p1.GetValue(0).ToString();
            int dmid = int.Parse(id1);
            q4.Parameters.AddWithValue("@dmid", dmid);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlCommand Q = new SqlCommand("Select MAX(mwid) from movieawards", con);
            SqlDataReader R = Q.ExecuteReader();
            R.Read();
            int newmwid = int.Parse(R.GetValue(0).ToString());
            newmwid = ++newmwid;
            SqlCommand Q1 = new SqlCommand("INSERT INTO movieawards VALUES @newmwid, @mid, @mname, @myear, @mevent, @mcategory)", con);
            Q1.Parameters.AddWithValue("@newid", newmwid);
            SqlCommand a = new SqlCommand("select mid from movies where Mname=@mname", con);
            a.Parameters.AddWithValue("@mname", mname.Text);
            SqlDataReader p = a.ExecuteReader();
            p.Read();
            string id = p.GetValue(0).ToString();
            int mid = int.Parse(id);
            Q1.Parameters.AddWithValue("@mid", mid);
            Q1.Parameters.AddWithValue("@mname", mname.Text);
            Q1.Parameters.AddWithValue("@myear", myear.Text);
            Q1.Parameters.AddWithValue("@mevent", mevent.Text);
            Q1.Parameters.AddWithValue("@mcategory", mcategory.Text);

            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);

        }
    }
}