﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class showtimeinsert : System.Web.UI.Page
    {
        SqlConnection con;

        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();

        }



        protected void Button1_Click1(object sender, EventArgs e)
        {
            SqlCommand q2 = new SqlCommand("Select MAX(showid) from showtimes", con);
            SqlDataReader r1 = q2.ExecuteReader();
            r1.Read();
            int newid = int.Parse(r1.GetValue(0).ToString());
            newid = ++newid;
            r1.Close();
            string movieName = TextBox4.Text;

            SqlCommand command = new SqlCommand("SELECT mid FROM movies WHERE mname = @movieName", con);
            command.Parameters.AddWithValue("@movieName", movieName);

            SqlDataReader reader = command.ExecuteReader();
            int movieId = 0;
            if (reader.Read())
            {
                movieId = reader.GetInt32(0); // Assuming the `mid` column is of type INT
                                              // Use the movieId as needed
            }
            reader.Close();

            //   SqlCommand q1 = new SqlCommand($"Insert into showtimes values({newid},'" + TextBox1.Text + "','" + (TextBox13.Text) + "','" + Time.Parse(TextBox3.Text) + "','" + (TextBox2.Text) + "',{movieId})", con);
            // q1.ExecuteNonQuery();
            SqlCommand q1 = new SqlCommand("INSERT INTO showtimes VALUES (@newid, @cinema, @city, @time, @date, @movieId)", con);
            q1.Parameters.AddWithValue("@newid", newid);
            q1.Parameters.AddWithValue("@cinema", TextBox1.Text);
            q1.Parameters.AddWithValue("@city", TextBox13.Text);
            q1.Parameters.AddWithValue("@time", TimeSpan.Parse(TextBox3.Text));
            q1.Parameters.AddWithValue("@date", TextBox2.Text);
            q1.Parameters.AddWithValue("@movieId", movieId);
            q1.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Inserted');", true);
        }
    }
}