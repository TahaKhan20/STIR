﻿    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class actorupdate : System.Web.UI.Page
    {
        SqlConnection con;
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {

            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();


        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            SqlCommand s23 = new SqlCommand($"Select * from aextra where aid in (select aid from actorssss where aname='{TextBox13.Text}') AND  date1='{(TextBox14.Text)}'", con);
            SqlDataReader r1 = s23.ExecuteReader();
            r1.Read();
            id = int.Parse(r1.GetValue(0).ToString());
            r1.Close();


            string name = string.Empty;
            string description = string.Empty;
            string image = string.Empty;
            string video = string.Empty;
            string socialID1 = string.Empty;
            string socialID2 = string.Empty;
            string socialID3 = string.Empty;
            string link1 = string.Empty;
            string link2 = string.Empty;
            string link3 = string.Empty;
            string iid1 = string.Empty;
            string iid2 = string.Empty;
            string iid3 = string.Empty;
            string dFlag = string.Empty;
            string wiki = string.Empty;
            string image1 = string.Empty;
            string image2 = string.Empty;
            string image3 = string.Empty;
            string s1 = string.Empty;
            string s2 = string.Empty;
            string s3 = string.Empty;


            if (txtdes.Text != "")
            {
                name = txtdes.Text.Substring(0, Math.Min(txtdes.Text.Length, 50));
            }

            if (TextBox21.Text != "")
            {
                string date = (TextBox21.Text).ToString();
            }

            if (TextBox1.Text != "")
            {
                description = TextBox1.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000));
            }



            if (TextBox3.Text != "")
            {
                image = TextBox3.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000));
            }

            if (TextBox9.Text != "")
            {
                video = TextBox9.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000));
            }

            if (TextBox10.Text != "")
            {
                socialID1 = TextBox10.Text.Substring(0, Math.Min(txtdes.Text.Length, 1000));
            }

            if (TextBox11.Text != "")
            {

                socialID2 = TextBox11.Text.Substring(0, Math.Min(txtdes.Text.Length, 1000));
            }

            if (TextBox8.Text != "")
            {

                socialID3 = TextBox8.Text.Substring(0, Math.Min(txtdes.Text.Length, 1000));
            }

            if (TextBox7.Text != "")
            {

                link1 = TextBox7.Text.Substring(0, Math.Min(txtdes.Text.Length, 4000));
            }
            if (TextBox6.Text != "")
            {

                link2 = TextBox6.Text.Substring(0, Math.Min(txtdes.Text.Length, 4000));
            }

            if (TextBox12.Text != "")
            {

                link3 = TextBox12.Text.Substring(0, Math.Min(txtdes.Text.Length, 4000));
            }

            if (TextBox4.Text != "")
            {

                iid1 = TextBox4.Text.Substring(0, Math.Min(txtdes.Text.Length, 400));
            }

            if (TextBox5.Text != "")
            {

                iid2 = TextBox5.Text.Substring(0, Math.Min(txtdes.Text.Length, 400));
            }

            if (TextBox13.Text != "")
            {

                iid3 = TextBox13.Text.Substring(0, Math.Min(txtdes.Text.Length, 400));
            }

            if (TextBox14.Text != "")
            {

                dFlag = TextBox14.Text.Substring(0, Math.Min(txtdes.Text.Length, 1)); ;
            }
            if (TextBox15.Text != "")
            {

                wiki = TextBox15.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000));
            }

            if (TextBox15.Text != "")
            {

                image1 = TextBox15.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000)); ;
            }
            if (TextBox16.Text != "")
            {

                image2 = TextBox16.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000)); ;
            }

            if (TextBox17.Text != "")
            {

                image3 = TextBox17.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000)); ;
            }

            if (TextBox18.Text != "")
            {
                s1 = TextBox18.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000)); ;

            }

            if (TextBox19.Text != "")
            {

                s2 = TextBox19.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000)); ;
            }

            if (TextBox20.Text != "")
            {

                s3 = TextBox20.Text.Substring(0, Math.Min(txtdes.Text.Length, 5000)); ;
            }







            // UpdateActorExtra(date, TextBox22.Text, TextBox23.Text, TextBox24.Text, TextBox25.Text, TextBox26.Text, TextBox27.Text, TextBox28.Text, TextBox29.Text, TextBox30.Text);

            //    string query = "UPDATE actorssss SET AName ='{Name}', ADesc = '{description}', AImage = '{image}', AVideo = '{Video}', Sid1 = '{SocialID1}', Sid2 = '{SocialID2}', Sid3 = '{SocialID3}', Link1 = '{Link1}', Link2 = '{Link2}', Link3 = '{Link3}', iid1 = '{IID1}', iid2 = '{IID2}', iid3 = '{iid3}, dFlag = '{DFlag}', Wiki = '{Wiki}', Im1 = '{Image1}', Im2 = '{Image2}', Im3 = '{Image3}', S1 = '{S1}', S2 = '{s2}', S3 = '{s3} WHERE AID = @ActorID";
            //  SqlCommand s45 = new SqlCommand(query);
            //   s45.ExecuteNonQuery();
            string query = "UPDATE actor SET AName = @Name, ADesc = @Description, AImage = @Image, AVideo = @Video, Sid1 = @SocialID1, Sid2 = @SocialID2, Sid3 = @SocialID3, Link1 = @Link1, Link2 = @Link2, Link3 = @Link3, iid1 = @IID1, iid2 = @IID2, iid3 = @IID3, dFlag = @DFlag, Wiki = @Wiki, Im1 = @Image1, Im2 = @Image2, Im3 = @Image3, S1 = @S1, S2 = @S2, S3 = @S3 WHERE AID = @ActorID";
            SqlCommand s45 = new SqlCommand(query, con);
            s45.Parameters.AddWithValue("@Name", name);
            s45.Parameters.AddWithValue("@Description", description);
            s45.Parameters.AddWithValue("@Image", image);
            s45.Parameters.AddWithValue("@Video", video);
            s45.Parameters.AddWithValue("@SocialID1", socialID1);
            s45.Parameters.AddWithValue("@SocialID2", socialID2);
            s45.Parameters.AddWithValue("@SocialID3", socialID3);
            s45.Parameters.AddWithValue("@Link1", link1);
            s45.Parameters.AddWithValue("@Link2", link2);
            s45.Parameters.AddWithValue("@Link3", link3);
            s45.Parameters.AddWithValue("@IID1", iid1);
            s45.Parameters.AddWithValue("@IID2", iid2);
            s45.Parameters.AddWithValue("@IID3", iid3);
            s45.Parameters.AddWithValue("@DFlag", dFlag);
            s45.Parameters.AddWithValue("@Wiki", wiki);
            s45.Parameters.AddWithValue("@Image1", image1);
            s45.Parameters.AddWithValue("@Image2", image2);
            s45.Parameters.AddWithValue("@Image3", image3);
            s45.Parameters.AddWithValue("@S1", s1);
            s45.Parameters.AddWithValue("@S2", s2);
            s45.Parameters.AddWithValue("@S3", s3);
            s45.Parameters.AddWithValue("@ActorID", id);
            s45.ExecuteNonQuery();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Updated');", true);
        }





    }
}