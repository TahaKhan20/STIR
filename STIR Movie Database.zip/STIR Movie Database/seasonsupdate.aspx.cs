﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace DB_Project
{
    public partial class seasonsupdate : System.Web.UI.Page
    {
        SqlConnection con;
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();

        }


        protected void Button1_Click1(object sender, EventArgs e)
        {
            SqlCommand s23 = new SqlCommand($"Select * from seasonss where sname='{TextBox13.Text}' AND  sdate={int.Parse(TextBox14.Text)}", con);
            SqlDataReader r1 = s23.ExecuteReader();
            r1.Read();
            id = int.Parse(r1.GetValue(0).ToString());
            r1.Close();

            string name;
            int Date;
            string desc;
            float rating;
            string trailer;
            string poster;
            int pg;
            string main;
            string mainposter;
            int s;
            if (TextBox10.Text != "")
            {
                s = int.Parse(TextBox10.Text);
            }
            else
            {
                s = int.Parse(r1.GetValue(7).ToString());
            }
            if (TextBox1.Text != "")
            {
                name = TextBox1.Text;
            }
            else
            {
                name = r1.GetValue(1).ToString();
            }

            if (TextBox2.Text != "")
            {
                Date = int.Parse(TextBox2.Text);
            }
            else
            {
                Date = int.Parse(r1.GetValue(2).ToString());
            }
            if (TextBox3.Text != "")
            {
                desc = TextBox3.Text;
            }
            else
            {
                desc = r1.GetValue(3).ToString();
            }
            if (TextBox4.Text != "")
            {
                rating = float.Parse(TextBox4.Text);
            }
            else
            {
                rating = float.Parse(r1.GetValue(4).ToString());
            }
            if (TextBox5.Text != "")
            {
                trailer = TextBox5.Text;
            }
            else
            {
                trailer = r1.GetValue(5).ToString();
            }
            if (TextBox6.Text != "")
            {
                poster = TextBox6.Text;
            }
            else
            {
                poster = r1.GetValue(6).ToString();
            }
            if (TextBox7.Text != "")
            {
                pg = int.Parse(TextBox7.Text);
            }
            else
            {
                pg = int.Parse(r1.GetValue(8).ToString());
            }
            if (TextBox8.Text != "")
            {
                main = TextBox8.Text;
            }
            else
            {
                main = r1.GetValue(9).ToString();
            }
            if (TextBox9.Text != "")
            {
                mainposter = TextBox9.Text;
            }
            else
            {
                mainposter = r1.GetValue(10).ToString();
            }

            SqlCommand s7 = new SqlCommand($"Update seasonss set sname='{name}',sdate={Date},sdesc='{desc}',srating={rating},strailer='{trailer}',sposter='{poster}',snos='{s}',spg={pg},maingenre='{main}',mainposter='{mainposter}' where sname='{TextBox13.Text}' AND sdate={int.Parse(TextBox14.Text)}", con);
            s7.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Updated');", true);
        }
    }

}