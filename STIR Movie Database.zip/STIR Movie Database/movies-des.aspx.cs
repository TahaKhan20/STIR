﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class movies_des : System.Web.UI.Page
    {
        SqlConnection con;
        protected void Page_Load(object sender, EventArgs e)
        {
            string parameterValue = Request.QueryString["i"];
            // string check = Request.QueryString["m"];
            int m = 0;
            string val; string val1;
            string val2;
            /*if(int.Parse(check)==0)
            {
                val = "seasons";
                val1 = "Sgenres";
                val2 = "Sid";
            }
            else
            {*/
            val = "movies";
            val1 = "Mgenres";
            val2 = "MID";

            //   }
            int id = int.Parse(parameterValue);
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();

            SqlCommand coun = new SqlCommand($"Select * from {val} where {val2}={id}", con);
            SqlDataReader r1 = coun.ExecuteReader();
            r1.Read();
            poster.ImageUrl = r1.GetValue(6).ToString();
            string src = r1.GetValue(5).ToString();
            rate.Text = r1.GetValue(4).ToString();
            desc.Text = r1.GetValue(3).ToString();
            name.Text = r1.GetValue(1).ToString();
            date.Text = r1.GetValue(2).ToString();
            pg.Text = r1.GetValue(8).ToString();
            frame.Text = $"<iframe style=\"margin - left: 2 %; ; \" width=\"800\" height=\"515\" src=\"{src}\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>";
            SqlCommand genc = new SqlCommand($"Select COUNT(*) from {val1} where {val2}={id}", con);
            SqlDataReader r3 = genc.ExecuteReader();
            r3.Read();
            int genrecount = (int.Parse(r3.GetValue(0).ToString()));
            int x = 0;
            SqlCommand gen = new SqlCommand($"Select * from {val1} where {val2}={id}", con);
            SqlDataReader r4 = gen.ExecuteReader();

            if (x < genrecount)
            {
                r4.Read();
                string gen1 = r4.GetValue(1).ToString();
                genre1.Text = gen1;
                genre2panel.Style["Display"] = "inline-block";
            }
            else
            {


            }
            x++;
            if (x < genrecount)
            {
                r4.Read();
                string gen1 = r4.GetValue(1).ToString();
                genre2.Text = gen1;
                genre3panel.Style["Display"] = "inline-block";
            }
            else
            {
                genre2panel.Visible = false;

            }
            x++;
            if (x < genrecount)
            {
                r4.Read();
                string gen1 = r4.GetValue(1).ToString();
                genre3.Text = gen1;
            }
            else
            {
                genre3panel.Visible = false;
                // genre3.Text = "lol";
                //  genre3.Visible = false;
            }


            //bod.Text= $"<body style = \"background-color: rgb(33, 47, 61);backdrop-filter: blur(8px); background-image: url(https://cdn.marvel.com/content/1x/maguiregarfieldholland_opt.jpg);\" >
            //  HtmlGenericControl bodyElement = (HtmlGenericControl)FindControl("body");
            /*Panel1.Style["background-image"] = "url('https://w0.peakpx.com/wallpaper/290/180/HD-wallpaper-spiderman-homecoming-movie-poster-spiderman-homecoming-spiderman-2019-movies-movies.jpg')";
            Panel1.Style["filter"] = "blur(8px)";*/
            // Set the background image
            // bodyElement.Style["background-image"] = "url('https://cdn.marvel.com/content/1x/maguiregarfieldholland_opt.jpg')";
        }
    }
}