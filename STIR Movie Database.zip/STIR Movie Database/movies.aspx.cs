﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class movies : System.Web.UI.Page
    {
        string iframe1Url;
        int i = 0;
        int i1 = 0;
        int i2 = 0;
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        string aimg1;
        string aimg2;
        string aimg3;
        string aimg4;
        string aimg5; string aimg6; string aimg7; string aimg8; string aimg9; string aimg10; string aimg11; string aimg12;
        SqlConnection con;
        protected void move1(object sender, EventArgs e)
        {
            SqlCommand comm = new SqlCommand("Select * from movies where maingenre='Action'", con);
            SqlDataReader r = comm.ExecuteReader();

            int x = 0;
            while (x < i && x < count1)
            {
                r.Read();
                x++;
            }
            if (x < count1)
            {
                r.Read();
                aimg1 = r.GetValue(10).ToString();
                //iframe1Url = r.GetValue(5).ToString();
                string ids = r.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44320/movies-des.aspx?i={id}";
                Lit1.Text = $"<a class=\"hov\" style=\"visibility:visible; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";
                // ifrm1.Text = $"<iframe src=\"{iframe1Url}\" width=\"330\" height=\"200\" id=\"ifrm1\" name=\"ifrm1\" style=\"margin-top:400px;margin-left:10px\"; position: absolute></iframe>";

                // aimg1.Visible = true;
            }
            else
            {
                Lit1.Text = $"<a id=\"abc\" style=\"visibility:hidden; margin-left:8px; width: 330px; height: 200px\" href=\"https://localhost:44312/WebForm2.aspx\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";

                //  aimg1.Visible = false;
            }
            x++;

            if (x < count1)
            {

                r.Read();
                aimg2 = r.GetValue(10).ToString();
                string ids = r.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44320/movies-des.aspx?i={id}";
                Lit2.Text = $"<a class=\"hov\" style=\"visibility:visible;margin-left:8px; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg2}\" ></img></a>";

            }
            else
            {
                Lit2.Text = $"<a style=\"visibility:hidden;margin-left:8px; width: 330px; height: 200px\" href=\"https://localhost:44312/WebForm2.aspx\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg2}\" ></img></a>";

            }
            x++;

            if (x < count1)
            {
                r.Read();
                aimg3 = r.GetValue(10).ToString();
                string ids = r.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44320/movies-des.aspx?i={id}";
                Lit3.Text = $"<a class=\"hov\" style=\"visibility:visible;margin-left:8px; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg3}\" ></img></a>";

                // aimg3.Visible = true;
            }
            else
            {
                Lit3.Text = $"<a style=\"visibility:hidden;margin-left:8px; width: 330px; height: 200px\" href=\"https://localhost:44312/WebForm2.aspx\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg3}\" ></img></a>";

            }
            x++;

            if (x < count1)
            {
                r.Read();
                aimg4 = r.GetValue(10).ToString();
                string ids = r.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44312/WebForm2.aspx?i={id}";
                Lit4.Text = $"<a class=\"hov1\" style=\"visibility:visible;margin-left:8px; width: 150px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov1\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"150px\" height=\"200px\" src=\"{aimg4}\" ></img></a>";

            }
            else
            {
                Lit4.Text = $"<a class=\"hov1\" style=\"visibility:hidden;margin-left:8px; width: 150px; height: 200px\" href=\"https://localhost:44312/WebForm2.aspx\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"150px\" height=\"200px\" src=\"{aimg4}\" ></img></a>";
            }
            x++;
            r.Close();
        }
        protected void move2(object sender, EventArgs e)
        {
            SqlCommand get2 = new SqlCommand("Select * from movies where maingenre='Mystery'", con);
            SqlDataReader r2 = get2.ExecuteReader();
            int x1 = 0;
            while (x1 < i1 && x1 < count2)
            {
                r2.Read();
                x1++;
            }
            if (x1 < count2)
            {
                r2.Read();
                aimg5 = r2.GetValue(10).ToString();
                //iframe1Url = r.GetValue(5).ToString();
                string ids = r2.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44312/WebForm2.aspx?i={id}";
                Lit5.Text = $"<a class=\"hov\" style=\"visibility:visible; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg5\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg5}\" ></img></a>";

            }
            else
            {
                Lit5.Text = $"<a class=\"hov\" style=\"visibility:hidden; width: 330px; height: 200px\" href=\"\"><img runat=\"server\" id=\"aimg5\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";
            }
            x1++;

            if (x1 < count2)
            {
                r2.Read();
                aimg6 = r2.GetValue(10).ToString();
                //iframe1Url = r.GetValue(5).ToString();
                string ids = r2.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44312/WebForm2.aspx?i={id}";
                Lit6.Text = $"<a class=\"hov\" style=\"visibility:visible; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg6}\" ></img></a>";

            }
            else
            {
                Lit6.Text = $"<a class=\"hov\" style=\"visibility:hidden; width: 330px; height: 200px\" href=\"\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";

            }
            x1++;

            if (x1 < count2)
            {
                r2.Read();
                aimg7 = r2.GetValue(10).ToString();
                //iframe1Url = r.GetValue(5).ToString();
                string ids = r2.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44312/WebForm2.aspx?i={id}";
                Lit7.Text = $"<a class=\"hov\" style=\"visibility:visible; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg7}\" ></img></a>";

            }
            else
            {
                Lit7.Text = $"<a class=\"hov\" style=\"visibility:hidden; width: 330px; height: 200px\" href=\"\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";

            }
            x1++;

            if (x1 < count2)
            {
                r2.Read();
                aimg8 = r2.GetValue(10).ToString();
                //iframe1Url = r.GetValue(5).ToString();
                string ids = r2.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44312/WebForm2.aspx?i={id}";
                Lit8.Text = $"<a class=\"hov1\" style=\"visibility:visible; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"150px\" height=\"200px\" src=\"{aimg8}\" ></img></a>";

            }
            else
            {
                Lit8.Text = $"<a class=\"hov1\" style=\"visibility:hidden; width: 330px; height: 200px\" href=\"\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";

            }
            x1++;
            r2.Close();
        }
        protected void move3(object sender, EventArgs e)
        {
            SqlCommand get2 = new SqlCommand("Select * from movies where Mrating>=8.5", con);
            SqlDataReader r2 = get2.ExecuteReader();
            int x1 = 0;
            while (x1 < i2 && x1 < count3)
            {
                r2.Read();
                x1++;
            }
            if (x1 < count3)
            {
                r2.Read();
                aimg9 = r2.GetValue(10).ToString();
                //iframe1Url = r.GetValue(5).ToString();
                string ids = r2.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44312/WebForm2.aspx?i={id}";
                Lit9.Text = $"<a class=\"hov\" style=\"visibility:visible; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg9}\" ></img></a>";

            }
            else
            {
                Lit9.Text = $"<a class=\"hov\" style=\"visibility:hidden; width: 330px; height: 200px\" href=\"\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg9}\" ></img></a>";

            }
            x1++;

            if (x1 < count3)
            {
                r2.Read();
                aimg10 = r2.GetValue(10).ToString();
                //iframe1Url = r.GetValue(5).ToString();
                string ids = r2.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44312/WebForm2.aspx?i={id}";
                Lit10.Text = $"<a class=\"hov\" style=\"visibility:visible; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg10}\" ></img></a>";

            }
            else
            {
                Lit10.Text = $"<a class=\"hov\" style=\"visibility:hidden; width: 330px; height: 200px\" href=\"\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";

            }
            x1++;

            if (x1 < count3)
            {
                r2.Read();
                aimg11 = r2.GetValue(10).ToString();
                //iframe1Url = r.GetValue(5).ToString();
                string ids = r2.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44312/WebForm2.aspx?i={id}";
                Lit11.Text = $"<a class=\"hov\" style=\"visibility:visible; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg11}\" ></img></a>";

            }
            else
            {
                Lit11.Text = $"<a class=\"hov\" style=\"visibility:hidden; width: 330px; height: 200px\" href=\"\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";

            }
            x1++;

            if (x1 < count3)
            {
                r2.Read();
                aimg12 = r2.GetValue(10).ToString();
                //iframe1Url = r.GetValue(5).ToString();
                string ids = r2.GetValue(0).ToString();
                int id = int.Parse(ids);
                string url1 = $"https://localhost:44312/WebForm2.aspx?i={id}";
                Lit12.Text = $"<a class=\"hov\" style=\"visibility:visible; width: 330px; height: 200px\" href=\"{url1}\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"150px\" height=\"200px\" src=\"{aimg12}\" ></img></a>";

            }
            else
            {
                Lit12.Text = $"<a class=\"hov\" style=\"visibility:hidden; width: 330px; height: 200px\" href=\"\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";

            }
            x1++;
        }

        protected void ButtonNext1_Click(object sender, EventArgs e)
        {
            i += 3;
            move1(sender, e);
        }
        protected void ButtonBack1_Click(object sender, EventArgs e)
        {
            if (i > 0)
            {
                i -= 3;

                move1(sender, e);
            }
        }
        protected void ButtonNext2_Click(object sender, EventArgs e)
        {
            i1 += 3;
            move2(sender, e);
        }
        protected void ButtonBack2_Click(object sender, EventArgs e)
        {
            if (i2 > 0)
            {
                i2 -= 3;
                move2(sender, e);
            }

        }
        protected void ButtonNext3_Click(object sender, EventArgs e)
        {
            i2 += 3;
            move3(sender, e);
        }
        protected void ButtonBack3_Click(object sender, EventArgs e)
        {
            if (i2 > 0)
            {
                i -= 3;
                move3(sender, e);
            }

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            // link1.Text = "<a style=\"width:100;height:200\"  class=\"hov\" href=\"https://localhost:44312/WebForm2.aspx?index={i}\">hello</a>";

            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();

            SqlCommand coun = new SqlCommand("Select COUNT(*) from movies where maingenre='Action'", con);
            SqlDataReader r1 = coun.ExecuteReader();
            r1.Read();
            string cou = r1.GetValue(0).ToString();
            count1 = int.Parse(cou);
            r1.Close();
            SqlCommand coun2 = new SqlCommand("Select COUNT(*) from movies where maingenre='Mystery'", con);
            SqlDataReader r4 = coun2.ExecuteReader();
            r4.Read();
            string cou1 = r4.GetValue(0).ToString();
            count2 = int.Parse(cou1);
            r4.Close();
            SqlCommand coun3 = new SqlCommand("Select COUNT(*) from movies where Mrating>=8.5", con);
            SqlDataReader r5 = coun3.ExecuteReader();
            r5.Read();
            string cou2 = r5.GetValue(0).ToString();
            count3 = int.Parse(cou2);
            r5.Close();
            move1(sender, e);
            /* Lit1.Text = $"<a style=\"margin-left:8px; width: 330px; height: 200px\" href=\"https://localhost:44312/WebForm2.aspx\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg1}\" ></img></a>";
             Lit2.Text = $"<a style=\"margin-left:8px; width: 330px; height: 200px\" href=\"https://localhost:44312/WebForm2.aspx\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg2}\" ></img></a>";
             Lit3.Text = $"<a style=\"margin-left:8px; width: 330px; height: 200px\" href=\"https://localhost:44312/WebForm2.aspx\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg2}\" ></img></a>";
             Lit4.Text = $"<a style=\"margin-left:8px; width: 330px; height: 200px\" href=\"https://localhost:44312/WebForm2.aspx\"><img runat=\"server\" id=\"aimg1\" class=\"hov\" style=\"box - shadow: 1px 0px 10px gray; \" width =\"330px\" height=\"200px\" src=\"{aimg2}\" ></img></a>";
            */
            move2(sender, e);
            move3(sender, e);
            //seoncd





        }
    }
}