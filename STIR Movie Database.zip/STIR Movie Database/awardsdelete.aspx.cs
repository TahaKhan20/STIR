﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DB_Project
{
    public partial class awardsdelete : System.Web.UI.Page
    {
        SqlConnection con;
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-8LG3S67\\SQLSERVER;Initial Catalog=DB Project;Integrated Security=True;MultipleActiveResultSets=True");
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //SqlCommand q1 = new SqlCommand("DELETE aawards FROM aawards INNER JOIN movies ON aawards.mid = movies.mid WHERE cinema = @cinema AND dates = @date AND city = @city AND timing = @time AND showtimes.mid = @mid", con);
            //q1.Parameters.AddWithValue("@cinema", TextBox1.Text);
            //q1.Parameters.AddWithValue("@date", TextBox2.Text);
            //q1.Parameters.AddWithValue("@city", TextBox4.Text);
            //q1.Parameters.AddWithValue("@time", TextBox3.Text);
            //q1.Parameters.AddWithValue("@mid", TextBox5.Text);
            //q1.ExecuteNonQuery();
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Deleted')", true);
        }



        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlCommand q4 = new SqlCommand("delete from aawards where (did=@did and dname1=@dname and dyear1=@dyear and devent1=@devent and category=@dcategory and movie=@dmovie", con);
            q4.Parameters.AddWithValue("@dname", dname.Text);

            SqlCommand a4 = new SqlCommand("select did from director where Dname=@dname", con);
            a4.Parameters.AddWithValue("@dname", dname.Text);
            SqlDataReader p4 = a4.ExecuteReader();
            p4.Read();
            string id4 = p4.GetValue(0).ToString();
            int did = int.Parse(id4);
            p4.Close();
            q4.Parameters.AddWithValue("@did", did);

            q4.Parameters.AddWithValue("@dyear", dyear.Text);
            q4.Parameters.AddWithValue("@devent", devent.Text);
            q4.Parameters.AddWithValue("@dcategory", dcategory.Text);
            q4.Parameters.AddWithValue("@dmovie", dmovie.Text);


            SqlCommand a1 = new SqlCommand("select mid from movies where Mname=@mname", con);
            a1.Parameters.AddWithValue("@mname", mname.Text);
            SqlDataReader p1 = a1.ExecuteReader();
            int dmid = 0;
            if (p1.Read())
            {

                string id1 = p1.GetValue(0).ToString();
                dmid = int.Parse(id1);
            }

            q4.Parameters.AddWithValue("@dmid", dmid);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Deleted');", true);
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlCommand Q1 = new SqlCommand("delete from moviesawards where mid=@mid and  mname1=@mname and myear1=@myear and mevent1=@mevent and category=@mcategory)", con);

            SqlCommand a = new SqlCommand("select mid from movies where Mname=@mname", con);
            a.Parameters.AddWithValue("@mname", mname.Text);
            SqlDataReader p = a.ExecuteReader();

            int mid = 0;

            if (p.Read())
            {
                string id = p.GetValue(0).ToString();
                mid = int.Parse(id);
            }
            p.Close();
            Q1.Parameters.AddWithValue("@mid", mid);
            Q1.Parameters.AddWithValue("@mname", mname.Text);
            Q1.Parameters.AddWithValue("@myear", myear.Text);
            Q1.Parameters.AddWithValue("@mevent", mevent.Text);
            Q1.Parameters.AddWithValue("@mcategory", mcategory.Text);

            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Deleted');", true);
        }

        protected void Button1_Click2(object sender, EventArgs e)
        {

            SqlCommand q1 = new SqlCommand("delete from aawards where (aid=@aid and aname1=@aname and ayear1=@ayear and aevent1=@aevent and category=@acategory and movie=@amovie)", con);

            SqlCommand a3 = new SqlCommand("select aid from actors where Aname=@aname", con);
            a3.Parameters.AddWithValue("@aname", aname.Text);
            SqlDataReader p3 = a3.ExecuteReader();
            p3.Read();
            string id3 = p3.GetValue(0).ToString();
            int aid = int.Parse(id3);
            q1.Parameters.AddWithValue("@aid", aid);

            q1.Parameters.AddWithValue("@aname", aname.Text);
            q1.Parameters.AddWithValue("@ayear", ayear.Text);
            q1.Parameters.AddWithValue("@aevent", aevent.Text);
            q1.Parameters.AddWithValue("@acategory", acategory.Text);
            q1.Parameters.AddWithValue("@amovie", amovie.Text);
            p3.Close();
            SqlCommand a2 = new SqlCommand("select mid from movies where Mname=@mname", con);
            a2.Parameters.AddWithValue("@mname", amovie.Text);
            SqlDataReader p2 = a2.ExecuteReader();
            int amid = 0;
            if (p2.Read())
            {
                string id2 = p2.GetValue(0).ToString();
                amid = int.Parse(id2);
            }
            q1.Parameters.AddWithValue("@amid", amid);

            p2.Close();

            q1.ExecuteNonQuery();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Successfully Deleted');", true);
        }
    }
}